<?php

namespace JS\JsCourses\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Jainish Senjaliya <jainishsenjaliya@gmail.com>
 *           Jainish Senjaliya <jainishsenjaliya@gmail.com>
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \JS\JsCourses\Domain\Model\Booking.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Jainish Senjaliya <jainishsenjaliya@gmail.com>
 * @author Jainish Senjaliya <jainishsenjaliya@gmail.com>
 */
class BookingTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {
	/**
	 * @var \JS\JsCourses\Domain\Model\Booking
	 */
	protected $subject = NULL;

	protected function setUp() {
		$this->subject = new \JS\JsCourses\Domain\Model\Booking();
	}

	protected function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getSalutationReturnsInitialValueForInteger() {
		$this->assertSame(
			0,
			$this->subject->getSalutation()
		);
	}

	/**
	 * @test
	 */
	public function setSalutationForIntegerSetsSalutation() {
		$this->subject->setSalutation(12);

		$this->assertAttributeEquals(
			12,
			'salutation',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getTitleReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getTitle()
		);
	}

	/**
	 * @test
	 */
	public function setTitleForStringSetsTitle() {
		$this->subject->setTitle('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'title',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getNameReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getName()
		);
	}

	/**
	 * @test
	 */
	public function setNameForStringSetsName() {
		$this->subject->setName('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'name',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getLastNameReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getLastName()
		);
	}

	/**
	 * @test
	 */
	public function setLastNameForStringSetsLastName() {
		$this->subject->setLastName('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'lastName',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getDobReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getDob()
		);
	}

	/**
	 * @test
	 */
	public function setDobForStringSetsDob() {
		$this->subject->setDob('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'dob',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getOccupationReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getOccupation()
		);
	}

	/**
	 * @test
	 */
	public function setOccupationForStringSetsOccupation() {
		$this->subject->setOccupation('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'occupation',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getStreetReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getStreet()
		);
	}

	/**
	 * @test
	 */
	public function setStreetForStringSetsStreet() {
		$this->subject->setStreet('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'street',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getHousenumberReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getHousenumber()
		);
	}

	/**
	 * @test
	 */
	public function setHousenumberForStringSetsHousenumber() {
		$this->subject->setHousenumber('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'housenumber',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getZipReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getZip()
		);
	}

	/**
	 * @test
	 */
	public function setZipForStringSetsZip() {
		$this->subject->setZip('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'zip',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPlaceReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getPlace()
		);
	}

	/**
	 * @test
	 */
	public function setPlaceForStringSetsPlace() {
		$this->subject->setPlace('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'place',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCountryReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getCountry()
		);
	}

	/**
	 * @test
	 */
	public function setCountryForStringSetsCountry() {
		$this->subject->setCountry('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'country',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getWorkPhoneReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getWorkPhone()
		);
	}

	/**
	 * @test
	 */
	public function setWorkPhoneForStringSetsWorkPhone() {
		$this->subject->setWorkPhone('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'workPhone',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPrivatePhoneReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getPrivatePhone()
		);
	}

	/**
	 * @test
	 */
	public function setPrivatePhoneForStringSetsPrivatePhone() {
		$this->subject->setPrivatePhone('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'privatePhone',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFaxReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getFax()
		);
	}

	/**
	 * @test
	 */
	public function setFaxForStringSetsFax() {
		$this->subject->setFax('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'fax',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getEmailReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getEmail()
		);
	}

	/**
	 * @test
	 */
	public function setEmailForStringSetsEmail() {
		$this->subject->setEmail('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'email',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getBillingAddressReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getBillingAddress()
		);
	}

	/**
	 * @test
	 */
	public function setBillingAddressForStringSetsBillingAddress() {
		$this->subject->setBillingAddress('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'billingAddress',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getOtherMessagesReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getOtherMessages()
		);
	}

	/**
	 * @test
	 */
	public function setOtherMessagesForStringSetsOtherMessages() {
		$this->subject->setOtherMessages('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'otherMessages',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getBookedCourseInWaitingListReturnsInitialValueForBoolean() {
		$this->assertSame(
			FALSE,
			$this->subject->getBookedCourseInWaitingList()
		);
	}

	/**
	 * @test
	 */
	public function setBookedCourseInWaitingListForBooleanSetsBookedCourseInWaitingList() {
		$this->subject->setBookedCourseInWaitingList(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'bookedCourseInWaitingList',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getDifferentBillingAddressReturnsInitialValueForBoolean() {
		$this->assertSame(
			FALSE,
			$this->subject->getDifferentBillingAddress()
		);
	}

	/**
	 * @test
	 */
	public function setDifferentBillingAddressForBooleanSetsDifferentBillingAddress() {
		$this->subject->setDifferentBillingAddress(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'differentBillingAddress',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getTrainingNewsletterReturnsInitialValueForBoolean() {
		$this->assertSame(
			FALSE,
			$this->subject->getTrainingNewsletter()
		);
	}

	/**
	 * @test
	 */
	public function setTrainingNewsletterForBooleanSetsTrainingNewsletter() {
		$this->subject->setTrainingNewsletter(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'trainingNewsletter',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getAccommodationsReturnsInitialValueForBoolean() {
		$this->assertSame(
			FALSE,
			$this->subject->getAccommodations()
		);
	}

	/**
	 * @test
	 */
	public function setAccommodationsForBooleanSetsAccommodations() {
		$this->subject->setAccommodations(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'accommodations',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCurrentTrainingProgramByMailReturnsInitialValueForBoolean() {
		$this->assertSame(
			FALSE,
			$this->subject->getCurrentTrainingProgramByMail()
		);
	}

	/**
	 * @test
	 */
	public function setCurrentTrainingProgramByMailForBooleanSetsCurrentTrainingProgramByMail() {
		$this->subject->setCurrentTrainingProgramByMail(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'currentTrainingProgramByMail',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCurrentTrainingProgramByEmailReturnsInitialValueForBoolean() {
		$this->assertSame(
			FALSE,
			$this->subject->getCurrentTrainingProgramByEmail()
		);
	}

	/**
	 * @test
	 */
	public function setCurrentTrainingProgramByEmailForBooleanSetsCurrentTrainingProgramByEmail() {
		$this->subject->setCurrentTrainingProgramByEmail(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'currentTrainingProgramByEmail',
			$this->subject
		);
	}
}
