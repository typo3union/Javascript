<?php 
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder


// $GLOBALS['TCA']['tx_jscourses_domain_model_category']['columns']['title']['config']['eval'] = 'required, trim';