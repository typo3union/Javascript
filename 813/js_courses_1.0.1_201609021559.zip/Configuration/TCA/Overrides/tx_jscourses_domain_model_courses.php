<?php 
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder
/*

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['types']['1']['showitem'] = 'sys_language_uid;;;;1-1-1, l10n_parent, l10n_diffsource, hidden;;1, title, subtitle, course_id, box_header, target_group;;;richtext:rte_transform[mode=ts_links], lessons, fortbildungs_point, prerequisites, availability, fee, information;;;richtext:rte_transform[mode=ts_links], file, logo, category, occupational,organizers, available_seat_management, event_date_period, speaker, guest_speakers, --div--;Buchungsliste, booking , --div--;LLL:EXT:cms/locallang_ttc.xlf:tabs.access, starttime, endtime';



$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['lessons']['config']['rows'] = 5;
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['title']['config']['eval'] = 'required, trim';

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['category']['config']['foreign_table_where'] = 'AND tx_jscourses_domain_model_category.pid=###CURRENT_PID### AND tx_jscourses_domain_model_category.sys_language_uid IN (-1,0)';
*/