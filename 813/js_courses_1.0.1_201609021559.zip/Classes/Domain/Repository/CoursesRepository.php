<?php
namespace JS\JsCourses\Domain\Repository;

use TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Courses
 */
class CoursesRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    
    /**
     * getCategoryList
     *
     * @param $settings
     * @return
     */
    public function getCategoryList($settings)
    {
        $field = 'uid, title, short_description, message';
        $table = 'tx_jscourses_domain_model_category';
        $groupBy = '';
        $orderBy = 'uid asc';
        $where = ' deleted = 0 AND hidden = 0 ';
        
        if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
            $where .= ' AND pid in (' . $settings['storagePID'] . ') ';
        }
        if (isset($settings['categoryList']) && trim($settings['categoryList']) != '') {
            $where .= ' AND uid in (' . $settings['categoryList'] . ') ';
        }
        
        $res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
        // echo $this->getDBHandle()->SELECTquery($field, $table, $where, $groupBy, $orderBy); die;
        foreach ($res as $key => $value) {
            if ($value['title'] !== '') {
                $cat[$value['uid']] = $value;
            }
        }
        return $cat;
    }
    
    /**
     * OccupationalList
     *
     * @param $settings
     * @return
     */
    public function getOccupationalList($settings) {

        $field = 'uid, title';
        $table = 'tx_jscourses_domain_model_occupational';
        $groupBy = '';
        $orderBy = 'uid asc';
        $where = ' deleted = 0 AND hidden = 0 ';
        if ($settings['newsletterTemplate'] == 0) {
            if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
                $where .= ' AND pid in (' . $settings['storagePID'] . ') ';
            }
        }
        $res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
        $occ = array();
        foreach ($res as $key => $value) {
            if ($value['title'] !== '') {
                $occ[$value['uid']] = $value;
            }
        }
        return $occ;
    }

    /**
     * getCourseList
     *
     * @param $settings
     * @return
     */
    public function getCourseList($settings)
    {
        $limit = '';
        $field = 'uid, title, pid';
        $table = 'tx_jscourses_domain_model_courses';
        $groupBy = '';
        $orderBy = 'uid asc';
        $where = ' deleted = 0 AND hidden = 0 AND title!="" ';
        $res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
        $courses = array();
        foreach ($res as $key => $value) {
            $courses[$value['uid']] = $value;
        }
        return $courses;
    }
    
    
    /* getCoursesTitle
     *
     */
    
    /**
     * @param $uid
     */
    public function getCoursesTitle($uid)
    {
        return $getRows = $this->getDBHandle()->exec_SELECTgetRows('title', 'tx_jscourses_domain_model_courses', 'hidden = 0 and deleted = 0 and uid =' . $uid);
    }
    
    /* getCourses
     *
     * @param $settings
     * @param $uid
     * @param $search
     * @param $arr
     * @return
     */
    
    /**
     * @param $settings
     * @param $uid
     * @param $search
     * @param $arr
     */
    public function getCourses($settings, $uid, $search, $arr)
    {
        //$this->getUpcomingCoursesID($settings);
        $limit = '';
        if (isset($settings['limit']) && $settings['limit'] > 0) {
            $limit = $settings['limit'];
        }
        $field = 'c.* , GROUP_CONCAT(DISTINCT(ctm.uid_foreign)) as categoryList, GROUP_CONCAT(DISTINCT(o.uid_foreign)) as occupationalList ';


        $table = 'tx_jscourses_domain_model_courses as c
						LEFT JOIN tx_jscourses_courses_category_mm AS ctm ON ctm.uid_local = c.uid  
                        LEFT JOIN tx_jscourses_courses_occupational_mm AS o ON o.uid_local = c.uid 
						';
        $orderBy = 'c.uid desc';

        $groupBy = 'c.uid';

        if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
            $where .= ' AND c.pid in (' . $settings['storagePID'] . ') ';
        }
        if (isset($settings['categoryList']) && trim($settings['categoryList']) != '') {
            $where .= ' AND ctm.uid_foreign in (' . $settings['categoryList'] . ') ';
        }

        $uid = intval($uid);
        if ($uid > 0) {
            $where .= ' AND c.uid = ' . $uid;
        }else{
            if (isset($search['title']) && trim($search['title']) != '') {
                
                $searchArr  = \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode(' ', $search['title'], true);
                
                $whr = array();

                foreach ($searchArr as $key => $value) {
                    $whr[] = ' c.title LIKE "%' . $value . '%" ';
                }
                
                $where .= ' AND ( '.implode($whr, " OR ").' ) ';

            }
            if (isset($search['id']) && trim($search['id']) != '') {
                $where .= ' AND c.course_id LIKE "%' . trim($search['id']) . '%"';
            }
        }

        $where = ' c.deleted = 0 AND c.hidden = 0 ' . $where;

        $res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy, $limit);
//        echo $this->getDBHandle()->SELECTquery($field, $table, $where, $groupBy, $orderBy, $limit); die;
        $res1 = $this->falImages($res, 'tx_jscourses_domain_model_courses');

        $catArr = $this->getCategoryList($settings);
        $occArr = $this->getOccupationalList($settings);

        $data = array();

        foreach ($res1 as $key => $value) {

            $catArr1 = array();

            if ($value['categoryList'] != '') {
                if (strstr($value['categoryList'], ',')) {
                    $cat = explode(',', $value['categoryList']);
                    foreach ($cat as $val) {
                        if (array_key_exists($val, $catArr)) {
                            $catArr1[$val] = $catArr[$val];
                        }
                    }
                } else {
                    if (array_key_exists($value['categoryList'], $catArr)) {
                        $catArr1[$value['categoryList']] = $catArr[$value['categoryList']];
                    }
                }
            }
            if (isset($search['category']) && $search['category'] > 0) {
                if (!array_key_exists($search['category'], $catArr1)) {
                    continue;
                }
            }

            $occArr1 = array();
            if ($value['occupationalList'] != '') {
                if (strstr($value['occupationalList'], ',')) {
                    $cat = explode(',', $value['occupationalList']);
                    foreach ($cat as $val) {
                        $occArr1[$val] = $occArr[$val];
                    }
                } else {
                    $occArr1[$value['occupationalList']] = $occArr[$value['occupationalList']];
                }
            }
            if (isset($search['occupational']) && $search['occupational'] > 0) {
                if (!array_key_exists($search['occupational'], $occArr1)) {
                    continue;
                }
            }
            
            $data[$value['uid']] = $value;
            $data[$value['uid']]['categories'] = $catArr1;
        }

        if ($uid > 0) {
            return $data[$uid];
        }
        return $data;
    }
    
    /**
     * getDBHandle
     *
     * @return
     */
    public function getDBHandle()
    {
        return $GLOBALS['TYPO3_DB'];
    }
    
    public function falImages($result, $tablename = NULL, $fieldname = NULL) {

        $where = '';

        if ($tablename != '') {
            $where = ' AND tablenames = "' . $tablename . '"';
        }
        if ($fieldname != '') {
            $where .= ' AND fieldname IN ("' . $fieldname . '")';
        }

        foreach ($result as $key => $value) {

            $whr = ' deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];
            $sysImages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr);
            $arr = '';

            foreach ($sysImages as $key1 => $value1) {

                $whr1  = 'uid = ' . $value1['uid_local'];

                $sysImageDetail = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file', $whr1);

                $arr1 = GeneralUtility::trimExplode('/', $sysImageDetail[0]['mime_type'], true);

                $arr[$value1['fieldname']][$value1['uid']] = array(

                        'identifier'=> 'fileadmin' . $sysImageDetail[0]['identifier'],
                        'title'  => $value1['title'],
                        'caption'   => $value1['description'],
                        'extension' => $sysImageDetail[0]['extension'],
                        'mime_type' => $sysImageDetail[0]['mime_type'],
                        'name'    => $sysImageDetail[0]['name'],
                        'uid'      => $sysImageDetail[0]['uid'],
                        'mime'    => $arr1[0],
                        'type'    => $arr1[1],
                        'imageName' => basename($sysImageDetail[0]['identifier']),
                    );
            }
            $result[$key]['media'] = $arr;
        }
        return $result;
    }

}