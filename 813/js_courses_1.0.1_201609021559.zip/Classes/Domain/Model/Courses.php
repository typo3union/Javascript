<?php
namespace JS\JsCourses\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Courses
 */
class Courses extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * title
     *
     * @var string
     */
    protected $title = '';
    
    /**
     * subtitle
     *
     * @var string
     */
    protected $subtitle = '';
    
    /**
     * courseId
     *
     * @var string
     */
    protected $courseId = '';
    
    /**
     * price
     *
     * @var string
     */
    protected $price = '';
    
    /**
     * displayPrice
     *
     * @var bool
     */
    protected $displayPrice = false;
    
    /**
     * shortDescription
     *
     * @var string
     */
    protected $shortDescription = '';
    
    /**
     * description
     *
     * @var string
     */
    protected $description = '';
    
    /**
     * image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $image = NULL;
    
    /**
     * category
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Category>
     */
    protected $category = NULL;
    
    /**
     * occupational
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Occupational>
     */
    protected $occupational = null;
    
    /**
     * Returns the title
     *
     * @return string $title
     */
    public function getTitle()
    {
        return $this->title;
    }
    
    /**
     * Sets the title
     *
     * @param string $title
     * @return void
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }
    
    /**
     * Returns the subtitle
     *
     * @return string $subtitle
     */
    public function getSubtitle()
    {
        return $this->subtitle;
    }
    
    /**
     * Sets the subtitle
     *
     * @param string $subtitle
     * @return void
     */
    public function setSubtitle($subtitle)
    {
        $this->subtitle = $subtitle;
    }
    
    /**
     * Returns the courseId
     *
     * @return string $courseId
     */
    public function getCourseId()
    {
        return $this->courseId;
    }
    
    /**
     * Sets the courseId
     *
     * @param string $courseId
     * @return void
     */
    public function setCourseId($courseId)
    {
        $this->courseId = $courseId;
    }
    
    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }
    
    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->category = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->occupational = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }
    
    /**
     * Adds a Category
     *
     * @param \JS\JsCourses\Domain\Model\Category $category
     * @return void
     */
    public function addCategory(\JS\JsCourses\Domain\Model\Category $category)
    {
        $this->category->attach($category);
    }
    
    /**
     * Removes a Category
     *
     * @param \JS\JsCourses\Domain\Model\Category $categoryToRemove The Category to be removed
     * @return void
     */
    public function removeCategory(\JS\JsCourses\Domain\Model\Category $categoryToRemove)
    {
        $this->category->detach($categoryToRemove);
    }
    
    /**
     * Returns the category
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Category> $category
     */
    public function getCategory()
    {
        return $this->category;
    }
    
    /**
     * Sets the category
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Category> $category
     * @return void
     */
    public function setCategory(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $category)
    {
        $this->category = $category;
    }
    
    /**
     * Returns the shortDescription
     *
     * @return string shortDescription
     */
    public function getShortDescription()
    {
        return $this->shortDescription;
    }
    
    /**
     * Sets the shortDescription
     *
     * @param string $shortDescription
     * @return void
     */
    public function setShortDescription($shortDescription)
    {
        $this->shortDescription = $shortDescription;
    }
    
    /**
     * Returns the description
     *
     * @return string description
     */
    public function getDescription()
    {
        return $this->description;
    }
    
    /**
     * Sets the description
     *
     * @param string $description
     * @return void
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }
    
    /**
     * Returns the image
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference image
     */
    public function getImage()
    {
        return $this->image;
    }
    
    /**
     * Sets the image
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     * @return void
     */
    public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image)
    {
        $this->image = $image;
    }
    
    /**
     * Returns the price
     *
     * @return string $price
     */
    public function getPrice()
    {
        return $this->price;
    }
    
    /**
     * Sets the price
     *
     * @param string $price
     * @return void
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }
    
    /**
     * Returns the displayPrice
     *
     * @return bool $displayPrice
     */
    public function getDisplayPrice()
    {
        return $this->displayPrice;
    }
    
    /**
     * Sets the displayPrice
     *
     * @param bool $displayPrice
     * @return void
     */
    public function setDisplayPrice($displayPrice)
    {
        $this->displayPrice = $displayPrice;
    }
    
    /**
     * Returns the boolean state of displayPrice
     *
     * @return bool
     */
    public function isDisplayPrice()
    {
        return $this->displayPrice;
    }
    
    /**
     * Adds a Occupational
     *
     * @param \JS\JsCourses\Domain\Model\Occupational $occupational
     * @return void
     */
    public function addOccupational(\JS\JsCourses\Domain\Model\Occupational $occupational)
    {
        $this->occupational->attach($occupational);
    }
    
    /**
     * Removes a Occupational
     *
     * @param \JS\JsCourses\Domain\Model\Occupational $occupationalToRemove The Occupational to be removed
     * @return void
     */
    public function removeOccupational(\JS\JsCourses\Domain\Model\Occupational $occupationalToRemove)
    {
        $this->occupational->detach($occupationalToRemove);
    }
    
    /**
     * Returns the occupational
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Occupational> $occupational
     */
    public function getOccupational()
    {
        return $this->occupational;
    }
    
    /**
     * Sets the occupational
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Occupational> $occupational
     * @return void
     */
    public function setOccupational(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $occupational)
    {
        $this->occupational = $occupational;
    }

}