<?php
namespace JS\JsCourses\Controller;

session_start();
/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * CoursesController
 */
class CoursesController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

	/**
	 * coursesService
	 *
	 * @var \JS\JsCourses\Service\CoursesService
	 * @inject
	 */
	protected $coursesService = NULL;
	
	/**
	 * coursesRepository
	 *
	 * @var \JS\JsCourses\Domain\Repository\CoursesRepository
	 * @inject
	 */
	protected $coursesRepository = NULL;
	
	/**
	 * action courses
	 *
	 * @return void
	 */
	public function coursesAction()
	{
		$GLOBALS['TSFE']->set_no_cache();
		$template = '0';
		$success = $errors = '';
		$this->settings['fullURL'] = $this->request->getBaseUri();

	  
		$uriParams = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET();
	   
		$category = $occupational = $speaker = '';
		$arr = array();
		
		if ($this->request->hasArgument('uid')) {
			$arr = $this->request->getArguments();
			$uid = $arr['uid'];
			$template = '1';
			$courseBrowserTitle = $this->coursesRepository->getCoursesTitle($uid);
			if ($courseBrowserTitle) {
				$GLOBALS['TSFE']->page['title'] = $courseBrowserTitle[0]['title'];
			}
		} else {

			$category	   = $this->coursesRepository->getCategoryList($this->settings);
		}

		$search = $this->request->getArguments();

		$searhArr = array();

		if (isset($_GET['q']) && $_GET['q'] == 1) {
			$searhArr['title']			= trim($search['title']);
			$searhArr['course_id']		= trim($search['id']);
			$searhArr['occupational']	= trim($search['occupational']);
			$searhArr['category']		 = trim($search['category']);
		} else {
			$searhArr['title'] = $searhArr['course_id'] = $searhArr['occupational'] = $searhArr['category'] = '';
		}

		$courses = $this->coursesRepository->getCourses($this->settings, $uid, $search, $arr);

	 
		$this->view->assign('template', $template);
		$this->view->assign('category', $category);
		
		$this->view->assign('errors', $errors);
		$this->view->assign('success', $success);
		$this->view->assign('courses', $courses);
		$this->view->assign('uriParams', $uriParams);
		$this->view->assign('search', $searhArr);
		// Include Additional Data
		$this->coursesService->includeAdditionalData($this->settings);
	}
	
	/**
	 * action search
	 *
	 * @return void
	 */
	public function searchAction()
	{
		$success = $errors = '';
		$this->settings['fullURL'] = $this->request->getBaseUri();

	  
		$uriParams = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET();

		if ($this->request->hasArgument('searchCourses')) {

			$search = $this->request->getArguments();

			$additionalParams = array();

			if($search['course_id'] != ''){
				$additionalParams['tx_jscourses_courses']['id'] = trim($search['course_id']);
			}
			if($search['title'] != ''){
				$additionalParams['tx_jscourses_courses']['title'] = trim($search['title']);
			}
			if($search['category'] != ''){
				$additionalParams['tx_jscourses_courses']['category'] = trim($search['category']);
			}
			if($search['occupational'] != ''){
				$additionalParams['tx_jscourses_courses']['occupational'] = trim($search['occupational']);
			}
			
			$additionalParams['q'] = '1';

			$this->redirectURL($GLOBALS['TSFE']->id, $additionalParams);
		}


		$category = $occupational = $speaker = '';

		$category = $this->coursesRepository->getCategoryList($this->settings);
		$occupational   = $this->coursesRepository->getOccupationalList($this->settings);

		$searhArr = array();

		if (isset($_GET['q']) && $_GET['q'] == 1) {
			$searhArr['title']			= trim($_GET['tx_jscourses_courses']['title']);
			$searhArr['course_id']		= trim($_GET['tx_jscourses_courses']['id']);
			$searhArr['category']		= trim($_GET['tx_jscourses_courses']['category']);
			$searhArr['occupational']	= trim($_GET['tx_jscourses_courses']['occupational']);
		} else {
			$searhArr['title'] = $searhArr['course_id'] = $searhArr['category'] = $searhArr['occupational'] = '';
		}

		$this->view->assign('category', $category);
		$this->view->assign('occupational', $occupational);

		$this->view->assign('uriParams', $uriParams);
		$this->view->assign('search', $searhArr);
		
	}

	
	/**
	 * redirectURL
	 *
	 * @param $pageUid
	 * @param $additionalParams
	 * @return
	 */
	public function redirectURL($pageUid = '', $additionalParams = array())
	{
		$pageUid = $pageUid > 0 ? $pageUid : $GLOBALS['TSFE']->id;
		$baseUri = $this->request->getBaseUri();
		$url = $this->uriBuilder->reset()->setTargetPageUid($pageUid)->setArguments($additionalParams)->buildFrontendUri();
		header('Location:' . $url);
		die;
	}
}