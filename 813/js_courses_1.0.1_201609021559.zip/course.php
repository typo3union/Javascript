<?php

ini_set("display_errors",1);

	class user_course
	{ 
		var $cObj;		// reference to the calling object.		 

		/**
		 * @var string
		*/
		protected $readonly = 'readonly="readonly"';

		function main($content,$conf) 
		{

			global $TYPO3_DB;

		//	$this->fullURL	= \TYPO3\CMS\Core\Utility\GeneralUtility::getIndpEnv('TYPO3_SITE_URL');
		//	$cObject		= \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('tslib_cObj');
			$lan			= (int)\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('L');

			$book 		= 0;

			$readonly 	= "";

			if(intVal($_GET['book'])>0){
				$book = $_GET['book'];
			}

			if(intVal($_REQUEST['tx_powermail_pi1']['field']['kursdatumHidden'])>0){
				$book = $_REQUEST['tx_powermail_pi1']['field']['kursdatumHidden'];
			}

			if($book>0){

				$field = 'uid, startdate , enddate';

				$table = 'tx_jscourses_domain_model_event';

				$where = ' deleted = 0 AND hidden = 0 AND courses = ' . $book;

				$data = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($field, $table, $where,'','startdate','1');

				$date = '';
				
				if(count($data[0]>0)){
					if(!empty($data[0]['startdate'])){
						$date = date("d.m.Y",$data[0]['startdate']);
						$date .= " (".date("H:i",$data[0]['startdate'])." Uhr)";
						$date .= " - ".date("d.m.Y",$data[0]['enddate']);
						$date .= " (".date("H:i",$data[0]['enddate'])." Uhr)";
					}
				}

				$readonly = $this->getReadonly();
			}

			$data	= '<div class="clearfix form-group powermail_fieldwrap_75803 " id="powermail_fieldwrap_75803">
							<div class="col-md-2 col-sm-3">
								<label title="" class="powermail_label" for="powermail_field_kursdatum"> Kursdatum </label>
							</div>
							<div class="col-md-8 col-sm-8">
								<input type="text" value="'.$date.'" name="tx_powermail_pi1[field][kursdatum]" id="powermail_field_kursdatum" class="form-control powermail_field powermail_input " data-parsley-id="6" '.$readonly.' />
								<input type="hidden" value="'.$book.'" name="tx_powermail_pi1[field][kursdatumHidden]" id="powermail_field_kursdatumHidden" class="form-control powermail_field powermail_input " data-parsley-id="6" />
							</div>
						</div>';

			return $data;

		}

		function courseTitle($content,$conf) 
		{

			global $TYPO3_DB;

			$lan	= (int)\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('L');

			$book = 0;

			$readonly = "";

			if(intVal($_GET['book'])>0){
				$book = $_GET['book'];
			}

			if(intVal($_REQUEST['tx_powermail_pi1']['field']['kursdatumHidden'])>0){
				$book = $_REQUEST['tx_powermail_pi1']['field']['kursdatumHidden'];
			}

			if($book>0){

				$field = 'uid, title , course_id';

				$table = 'tx_jscourses_domain_model_courses';

				$where = ' deleted = 0 AND hidden = 0 AND uid = ' . $book;

				$data = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($field, $table, $where);

				$course = '';

				if(count($data[0]>0)){
					if(!empty($data[0]['title'])){
						$course = $data[0]['course_id']." | ".$data[0]['title'];
					}
				}

				$readonly = $this->getReadonly();
			}

			$data	= '<div class="col-lg-12 powermail_fieldwrap powermail_fieldwrap_input powermail_fieldwrap_7 " id="powermail_fieldwrap_7">
							<span title="" class="powermail_label" for="powermail_field_kursnummer_name">
								Kursnummer/-name
							</span>
							<input type="text" value="'.$course.'" name="tx_powermail_pi1[field][kursnummer_name]" id="powermail_field_kursnummer_name" class="powermail_field powermail_input " data-parsley-id="16" '.$readonly.' >
						</div>';

			return $data;
		}

		/**
	     * @return string
	     */
		public function getReadonly()
		{
			return $this->readonly;
		}
	}
?>