CREATE TABLE pages (
	pageicon text,
	menuimage text,
	color  int(11) DEFAULT '0' NOT NULL,
);