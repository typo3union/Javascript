// jQuery to collapse the navbar on scroll
$(window).scroll(function() {
    if ($(".navbar").offset().top > 50) {
        $(".navbar-fixed-top").addClass("top-nav-collapse");
        $(".scroll-top").fadeIn('1000', "easeInOutExpo");
    } else {
        $(".navbar-fixed-top").removeClass("top-nav-collapse");
        $(".scroll-top").fadeOut('1000', "easeInOutExpo");
    }
});

// jQuery for page scrolling feature - requires jQuery Easing plugin


// Closes the Responsive Menu on Menu Item Click
$('.navbar-collapse ul li a').click(function() {
    $('.navbar-toggle:visible').click();
});

// Navigation show/hide
$('.toggle').click(function() {
	
	
    if ($('#overlay.open')) {
        $(this).toggleClass('active');
        $('#overlay').toggleClass('open');
    }
	
	if(!$('#overlay').hasClass( "open" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');			
	}
	
	$('.overlay1').removeClass('open');
	$('.toggle1').removeClass('active');
	
});

// Email show/hide
$('.toggle1').click(function() {
	
	if ($('#overlay1.open')) {
        $(this).toggleClass('active');
        $('#overlay1').toggleClass('open');
    }

	$('.overlay').removeClass('open');
	$('.toggle').removeClass('active');
	
	if(!$('#overlay1').hasClass( "open" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');			
	}

});


// HTML5 Player
$(function() {

    var vid = $("#html5-video").get(0);

    $('#html5-video-play').click(function(event) {
        event.preventDefault();
        if (vid.paused) {
            vid.play();
        } else {
            vid.pause();
        }
        $(this).toggleClass('fa-play fa-pause');
        return false;
    });

    $('#html5-video-volume').click(function(event) {
        event.preventDefault();
        if (vid.muted) {
            vid.muted = false;
        } else {
            vid.muted = true;
        }
        $(this).toggleClass('fa-volume-off fa-volume-up');
        return false;
    });
});



var videoPlayer = document.getElementById('video');
videoPlayer.controls = false;

/*video control custom */


window.onload = function() {
	
	jQuery('#play-pause').addClass("play-video");
	jQuery('#mute').addClass("unmute-video");

	// Video
	var video = document.getElementById("video");

	// Buttons
	var playButton = document.getElementById("play-pause");
	var muteButton = document.getElementById("mute");
	var fullScreenButton = document.getElementById("full-screen");

	// Sliders
	var seekBar = document.getElementById("seek-bar");
	var volumeBar = document.getElementById("volume-bar");


	// Event listener for the play/pause button
	playButton.addEventListener("click", function() {
		if (video.paused == true) {
			
			// Play the video
			video.play();
			// Update the button text to 'Pause'
			playButton.innerHTML = "Pause";
			jQuery('#play-pause').removeClass("play-video");
			jQuery('#play-pause').addClass("pause-video");
			
		} else {
			// Pause the video
			video.pause();

			// Update the button text to 'Play'
			playButton.innerHTML = "Play";
			jQuery('#play-pause').addClass("play-video");
			jQuery('#play-pause').removeClass("pause-video");
		}
	});


	// Event listener for the mute button
	muteButton.addEventListener("click", function() {
		if (video.muted == false) {
			// Mute the video
			video.muted = true;

			// Update the button text
			muteButton.innerHTML = "Unmute";
			jQuery('#mute').removeClass("unmute-video");
			jQuery('#mute').addClass("mute-video");
		} else {
			// Unmute the video
			video.muted = false;

			// Update the button text
			muteButton.innerHTML = "Mute";
			jQuery('#mute').addClass("unmute-video");
			jQuery('#mute').removeClass("mute-video");
		}
	});


	// Event listener for the full-screen button
	fullScreenButton.addE