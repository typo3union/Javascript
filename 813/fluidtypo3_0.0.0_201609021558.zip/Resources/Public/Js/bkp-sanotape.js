// jQuery to collapse the navbar on scroll
$(window).scroll(function() {
    if ($(".navbar").offset().top > 50) {
        $(".navbar-fixed-top").addClass("top-nav-collapse");
        $(".scroll-top").fadeIn('1000', "easeInOutExpo");
    } else {
        $(".navbar-fixed-top").removeClass("top-nav-collapse");
        $(".scroll-top").fadeOut('1000', "easeInOutExpo");
    }
});

// jQuery for page scrolling feature - requires jQuery Easing plugin



// WOW.js initialise
// WOW.js uses animate.css to animate/reveal elements.
// Browse the list of animation effects available here-> https://daneden.github.io/animate.css/

// jQuery Parallax. More info here-> https://github.com/IanLunn/jQuery-Parallax
$(function(){
    // apply parallax effect only when body has the ".parallax-page" class
    if ($('body').hasClass('parallax-page')) {
        //.parallax(xPosition, speedFactor, outerHeight) options:
        //xPosition - Horizontal position of the element
        //inertia - speed to move relative to vertical scroll. Example: 0.1 is one tenth the speed of scrolling, 2 is twice the speed of scrolling
        //outerHeight (true/false) - Whether or not jQuery should use it's outerHeight option to determine when a section is in the viewport
        
        $('#parallax-slide').parallax("50%", 0.1);
        $('#products').parallax("50%", 0.1);
        $('#portfolio').parallax("50%", 0.1);
        $('#page-aboutus').parallax("50%", 0.1);
    }
});


// Closes the Responsive Menu on Menu Item Click



// jQuery for page scrolling feature - requires jQuery Easing plugin
$(function() {
    $('a.page-scroll').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top
        }, 1500, 'easeInOutExpo');
        event.preventDefault();
    });
});


// Closes the Responsive Menu on Menu Item Click
$('.navbar-collapse ul li a').click(function() {
    $('.navbar-toggle:visible').click();
});

// Navigation show/hide
$('.toggle').click(function() {
	
	
    if ($('#overlay.open')) {
        $(this).toggleClass('active');
        $('#overlay').toggleClass('open');
    }
	/*if($('.navbar-header').hasClass( "active" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');			
	}*/
	
	
	if(!$('#overlay').hasClass( "open" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');			
	}
	
	$('.overlay1').removeClass('open');
	$('.toggle1').removeClass('active');
	
});
// Email show/hide
$('.toggle1').click(function() {
	
	/*if(!$('.main-outer').hasClass( "addBorder" )){
		$('.main-outer').addClass('addBorder');
	}
	$('.main-outer').addClass('addBorder');
	*/	
	if ($('#overlay1.open')) {
        $(this).toggleClass('active');
        $('#overlay1').toggleClass('open');
    }

	$('.overlay').removeClass('open');
	$('.toggle').removeClass('active');
	
	if(!$('#overlay1').hasClass( "open" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');			
	}
	
	/*if($('.navbar-header').hasClass( "active" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');	
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');	
	}*/
});



// Counter
$(function() {

    $('.counter-section').on('inview', function(event, visible, visiblePartX, visiblePartY) {
        if (visible) {
            $(this).find('.timer').each(function() {
                var $this = $(this);
                $({
                    Counter: 0
                }).animate({
                    Counter: $this.text()
                }, {
                    duration: 2000,
                    easing: 'swing',
                    step: function() {
                        $this.text(Math.ceil(this.Counter));
                    }
                });
            });
            $(this).off('inview');
        }
    });

});


// Carousel Slider
$(function() {
    interval: 8000 //changes the speed
});




// HTML5 Player
$(function() {

    var vid = $("#html5-video").get(0);

    $('#html5-video-play').click(function(event) {
        event.preventDefault();
        if (vid.paused) {
            vid.play();
        } else {
            vid.pause();
        }
        $(this).toggleClass('fa-play fa-pause');
        return false;
    });

    $('#html5-video-volume').click(function(event) {
        event.preventDefault();
        if (vid.muted) {
            vid.muted = false;
        } else {
            vid.muted = true;
        }
        $(this).toggleClass('fa-volume-off fa-volume-up');
        return false;
    });
});



var videoPlayer = document.getElementById('video');
videoPlayer.controls = false;

/*video control custom */


window.onload = function() {
	
	jQuery('#play-pause').addClass("play-video");
	jQuery('#mute').addClass("unmute-video");

	// Video
	var video = document.getElementById("video");

	// Buttons
	var playButton = document.getElementById("play-pause");
	var muteButton = document.getElementById("mute");
	var fullScreenButton = document.getElementById("full-screen");

	// Sliders
	var seekBar = document.getElementById("seek-bar");
	var volumeBar = document.getElementById("volume-bar");


	// Event listener for the play/pause button
	playButton.addEventListener("click", function() {
		if (video.paused == true) {
			
			// Play the video
			video.play();
			// Update the button text to 'Pause'
			playButton.innerHTML = "Pause";
			jQuery('#play-pause').removeClass("play-video");
			jQuery('#play-pause').addClass("pause-video");
			
		} else {
			// Pause the video
			video.pause();

			// Update the button text to 'Play'
			playButton.innerHTML = "Play";
			jQuery('#play-pause').addClass("play-video");
			jQuery('#play-pause').removeClass("pause-video");
		}
	});


	// Event listener for the mute button
	muteButton.addEventListener("click", function() {
		if (video.muted == false) {
			// Mute the video
			video.muted = true;

			// Update the button text
			muteButton.innerHTML = "Unmute";
			jQuery('#mute').removeClass("unmute-video");
			jQuery('#mute').addClass("mute-video");
		} else {
			// Unmute the video
			video.muted = false;

			// Update the button text
			muteButton.innerHTML = "Mute";
			jQuery('#mute').addClass("unmute-video");
			jQuery('#mute').removeClass("mute-video");
		}
	});


	// Event listener for the full-screen button
	fullScreenButton.addEventListener("click", function() {
		if (video.requestFullscreen) {
			video.requestFullscreen();
		} else if (video.mozRequestFullScreen) {
			video.mozRequestFullScreen(); // Firefox
		} else if (video.webkitRequestFullscreen) {
			video.webkitRequestFullscreen(); // Chrome and Safari
		}
	});


	// Event listener for the seek bar
	seekBar.addEventListener("change", function() {
		// Calculate the new time
		var time = video.duration * (seekBar.value / 100);

		// Update the video time
		video.currentTime = time;
	});
	
	
	// Update the seek bar as the video plays
	video.addEventListener("timeupdate", function() {
		// Calculate the slider value
		var value = (100 / video.duration) * video.currentTime;

		// Update the slider value
		seekBar.value = value;
	});

	// Pause the video when the seek handle is being dragged
	seekBar.addEventListener("mousedown", function() {
		video.pause();
	});

	// Play the video when the seek handle is dropped
	seekBar.addEventListener("mouseup", function() {
		video.play();
	});

	// Event listener for the volume bar
	volumeBar.addEventListener("change", function() {
		// Update the video volume
		video.volume = volumeBar.value;
	});
}

/*End*/



// Lightbox
/*$(function() {
    $('.popup-gallery').magnificPopup({
        delegate: '.full-project a',
        type: 'image',
        tLoading: 'Loading image #%curr%...',
        mainClass: 'mfp-img-mobile',
        gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [0,1] // Will preload 0 - before current, and 1 after the current image
        },
        image: {
            tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
            titleSrc: function(item) {
                return item.el.attr('title') + '<small>by Hallooou</small>';
            }
        }
	});
*/



//