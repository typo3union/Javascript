$(function(){
    //$('#demo-select_2').not('#demo-select_2').CustomSelect();
    $('#demo-select_2').CustomSelect({visRows:10, search:true, modifier: 'mod'});

    $("#map_canvas").addClass('disable');
    $('#map_canvas').click(function() {
        $("#map_canvas").removeClass('disable');
    });

});

$(window).resize(function(){
	$('#demo-select_2').trigger('click');	
});

$(window).resize(function(){
	/*var p = $( "#demo-select_2" );
	var offset = p.offset();
	var input_dropdown_height = $(".b-custom-select").height();
	var htop = parseInt(offset.top+input_dropdown_height);
	$(".b-custom-select__dropdown").css('top',htop).css('left',offset.left);*/
	//console.log(offset.top);
});

// jQuery to collapse the navbar on scroll
$(window).scroll(function() {
    if ($(".navbar").offset().top > 50) {
        $(".navbar-fixed-top").addClass("top-nav-collapse");
        $(".scroll-top").fadeIn('1000', "easeInOutExpo");
    } else {
        $(".navbar-fixed-top").removeClass("top-nav-collapse");
        $(".scroll-top").fadeOut('1000', "easeInOutExpo");
    }
});

// jQuery for page scrolling feature - requires jQuery Easing plugin


// Closes the Responsive Menu on Menu Item Click
$('.navbar-collapse ul li a').click(function() {
    $('.navbar-toggle:visible').click();
});

// Navigation show/hide
$('.toggle').click(function() {
	
	
    if ($('#overlay.open')) {
        $(this).toggleClass('active');
        $('#overlay').toggleClass('open');
    }
	
	if(!$('#overlay').hasClass( "open" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');			
	}
	
	$('.overlay1').removeClass('open');
	$('.toggle1').removeClass('active');
	
});

// Email show/hide
$('.toggle1').click(function() {
	
	if ($('#overlay1.open')) {
        $(this).toggleClass('active');
        $('#overlay1').toggleClass('open');
    }

	$('.overlay').removeClass('open');
	$('.toggle').removeClass('active');
	
	if(!$('#overlay1').hasClass( "open" )){
		$('.navbar-header').removeClass('active');
		$('.main-outer').removeClass('addBorder');
	}else{
		$('.navbar-header').addClass('active');
		$('.main-outer').addClass('addBorder');			
	}

});

$('.toggle3').click(function() {
	$('.overlay').removeClass('open');
	$('.toggle').removeClass('active');
	$('.main-outer').removeClass('addBorder');
	$('.navbar-header').removeClass('active');
});

$('.toggle4').click(function() {
	$('.overlay1').removeClass('open');
	$('.toggle1').removeClass('active');
	$('.main-outer').removeClass('addBorder');
	$('.navbar-header').removeClass('active');
});


// HTML5 Player
$(function() {

    var vid = $("#html5-video").get(0);

    $('#html5-video-play').click(function(event) {
        event.preventDefault();
        if (vid.paused) {
            vid.play();
        } else {
            vid.pause();
        }
        $(this).toggleClass('fa-play fa-pause');
        return false;
    });

    $('#html5-video-volume').click(function(event) {
        event.preventDefault();
        if (vid.muted) {
            vid.muted = false;
        } else {
            vid.muted = true;
        }
        $(this).toggleClass('fa-volume-off fa-volume-up');
        return false;
    });
});



/*video control custom */


window.onload = function() {

	if(jQuery('video').length > 0){
		
		jQuery('#play-pause').addClass("play-video");
		jQuery('#mute').addClass("unmute-video");

		// Video
		var video = document.getElementById("video");

		// Buttons
		var playButton = document.getElementById("play-pause");
		var muteButton = document.getElementById("mute");
		var fullScreenButton = document.getElementById("full-screen");

		// Sliders
		var seekBar = document.getElementById("seek-bar");
		var volumeBar = document.getElementById("volume-bar");


		// Event listener for the play/pause button
		playButton.addEventListener("click", function() {
			if (video.paused == true) {
				
				// Play the video
				video.play();
				// Update the button text to 'Pause'
				playButton.innerHTML = "Pause";
				jQuery('#play-pause').removeClass("play-video");
				jQuery('#play-pause').addClass("pause-video");
				
			} else {
				// Pause the video
				video.pause();

				// Update the button text to 'Play'
				playButton.innerHTML = "Play";
				jQuery('#play-pause').addClass("play-video");
				jQuery('#play-pause').removeClass("pause-video");
			}
		});


		// Event listener for the mute button
		muteButton.addEventListener("click", function() {
			if (video.muted == false) {
				// Mute the video
				video.muted = true;

				// Update the button text
				muteButton.innerHTML = "Unmute";
				jQuery('#mute').removeClass("unmute-video");
				jQuery('#mute').addClass("mute-video");
			} else {
				// Unmute the video
				video.muted = false;

				// Update the button text
				muteButton.innerHTML = "Mute";
				jQuery('#mute').addClass("unmute-video");
				jQuery('#mute').removeClass("mute-video");
			}
		});


		// Event listener for the full-screen button
		fullScreenButton.addEventListener("click", function() {
			if (video.requestFullscreen) {
				video.requestFullscreen();
			} else if (video.mozRequestFullScreen) {
				video.mozRequestFullScreen(); // Firefox
			} else if (video.webkitRequestFullscreen) {
				video.webkitRequestFullscreen(); // Chrome and Safari
			}
		});


		// Event listener for the seek bar
		seekBar.addEventListener("change", function() {
			// Calculate the new time
			var time = video.duration * (seekBar.value / 100);

			// Update the video time
			video.currentTime = time;
		});
		
		
		// Update the seek bar as the video plays
		video.addEventListener("timeupdate", function() {
			// Calculate the slider value
			var value = (100 / video.duration) * video.currentTime;

			// Update the slider value
			seekBar.value = value;
		});

		// Pause the video when the seek handle is being dragged
		seekBar.addEventListener("mousedown", function() {
			video.pause();
		});

		// Play the video when the seek handle is dropped
		seekBar.addEventListener("mouseup", function() {
			video.play();
		});

		// Event listener for the volume bar
		volumeBar.addEventListener("change", function() {
			// Update the video volume
			video.volume = volumeBar.value;
		});
	}
}

/*End*/

$(window).load(function(){


	$( '.flexslider' ).fitVids().flexslider({
		  animation: 'slide',
		  useCSS: false,
		  animationSpeed: 1000,
		  slideshowSpeed: 6000, 
		  animationLoop: true,
		  smoothHeight: false,
		  start: function( slider ) {
			$('body').removeClass( 'loading' );
		  },
		  before: function ( slider ) {
	//		wistiaEmbed.pause();
		  }
	});

	$( '.bannerSlider' ).fitVids().flexslider({
		  animation: 'slide',
		  useCSS: false,
		  animationSpeed: 1000,
		  slideshowSpeed: 6000, 
		  animationLoop: true,
		  smoothHeight: false,
		  start: function( slider ) {
			$('body').removeClass( 'loading' );
		  },
		  before: function ( slider ) {
	//		wistiaEmbed.pause();
		  }
	});
});


$(window).load(function() {
	sliderHeight();
});

$(window).on("resize", function() {
	
	sliderHeight();
});
	
function sliderHeight(){	

	//console.log($(this).width());
	//console.log($(this).height());
	
	var max1 = $( window ).height();
	
	if ($(this).width() > 1280) {
		
		setEqualHeight('.flexslider .slides li',1,max1+"px");
	   
	}else if($(this).width() < 1279) {
		setEqualHeight('.flexslider .slides li',2, "auto");
	  
	}else {

		console.log("525");
		 setEqualHeight('.flexslider .slides li',1,"auto");
	}
}

function setEqualHeight(selector,num, height) {

// var maxheight = max1/num;
 $('.flexslider .slides li').each(function(){
      $(this).css('height', height);
  });
}


/*var videoPlayer = document.getElementById('video');
videoPlayer.controls = false;*/

function pauseslider() { $('#slider').flexslider("pause"); }
function playslider() { $('#slider').flexslider("play"); }
function resumeslider() { $('#slider').flexslider("next"); $('#slider').flexslider("play"); }

function showDiv(elem){
	$(".dot-detail-div").hide(200);
	$(".dot-point").removeClass('selected');
	$("#p"+elem.value).addClass('selected');
	$("#i"+elem.value).slideToggle( "slow", function() {});
}

$(function(){
	checkSelection();

	//$(".dot-point").click(function(){
	$(".dot-point").on('click', function () {
		var _id = $(this).attr('data-id');

		$(".dot-point").removeClass('selected');
		$("#p"+_id).addClass('selected');
		
		$(".dot-detail-div").hide(200);
		$("#i"+_id).slideToggle( "slow", function() {});

		//$(".d_select").attr( "selected", ' ');
		//$("#demo-select_2 option").prop("selected", false);
		$("#demo-select_2 option").removeAttr('selected');
		$("#d"+_id).attr( "selected", 'selected');
		var _title = $("#d"+_id).text();
		$(".b-custom-select__title__input").val(_title);
	});
})

function checkSelection(){
	var _checkSelected = ($("#demo-select_2").val()) ? $("#demo-select_2").val() : 1;
	if(_checkSelected) {
		var elem = _checkSelected;
		$(".dot-detail-div").hide(200);
		$(".dot-point").removeClass('selected');
		$("#p"+elem).addClass('selected');
		$("#i"+elem).slideToggle( "slow", function() {});

		$("#demo-select_2 option").removeAttr('selected');
		$("#d"+elem).attr( "selected", 'selected');
		var _title = $("#d"+elem).text();
		$(".b-custom-select__title__input").val(_title);

	}
}

$(document).ready(function() {

   $('div.dot-point').on('click touchstart', function(e) {
      var el = $(this);
      var link = el.attr('');
      //window.location = ;
   });

});

