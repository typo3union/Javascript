page.headTag = <head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />


page.includeCSS {
    
    bootstrap	= {$filepaths.css}bootstrap.min.css
    scrollnavi	= {$filepaths.css}sanotape.css
    flexslider	= {$filepaths.css}flexslider.css
    settings	= {$filepaths.css}settings.css
    plugins		= {$filepaths.css}plugins.css
    font		= {$filepaths.css}font-awesome.min.css
    
    print		= {$filepaths.css}print.css
    print.media = print
}

page.includeJSlibs {
   jquery = {$filepaths.js}jquery.min.js
}

# Header Data Setup
page.headerData {
	10 = TEXT
	10.value (
		<link href='https://fonts.googleapis.com/css?family=Quattrocento+Sans:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
	)
}

page.includeJSFooterlibs {

    bootstrap	 = {$filepaths.js}bootstrap.min.js
	flexslider	 = {$filepaths.js}jquery.flexslider.js
	fitvid		 = {$filepaths.js}jquery.fitvid.js	
	app			 = {$filepaths.js}app.js
	customselect = {$filepaths.js}jquery.custom-select.js
	sanotape	 = {$filepaths.js}sanotape.js

}


# override meta tags if defined at page level
page.meta {
	keywords.override.field = keywords
	description.override.field = description
}


page = PAGE
page.typeNum = 0
page {
	
}