<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'FluidTypo3');
\FluidTYPO3\Flux\Core::registerProviderExtensionKey($_EXTKEY, 'Page');
\FluidTYPO3\Flux\Core::registerProviderExtensionKey($_EXTKEY, 'Content');


$thumbimage = array(
        'color' => array (
                'exclude' => 0,
                'label' => 'Theme - Select one theme',
                'config' => array (
                        'type' => 'select',
                        'renderType' => 'selectSingleBox',
                        'items' => array (
                                array('Default ', '0'),
                                array('weib ', '1'),
                                array('magenta ', '2'),
                                array('rose ', '3'),
                                array('anthrazit ', '4'),
                                array('reflexo muttermarke ', '5'),
                                array('reflexo strip ', '6'),
                                array('reflexo set ', '7'),
                                array('reflexo dental ', '8'),
                                array('reflexo animal ', '9'),
                                array('reflexo tcm ', '10'),
                                array('reflexo profile ', '11'),
                                array('reflexo skin ', '12'),
                                array('reflexo med ', '13'),
                                array('reflexo speed ', '14'),
                        ),
                        'size' => 10,
                        'autoSize' => 14,

                        'maxitems' => 1,
                )
        ),
);


\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns(
        'pages',        
        $thumbimage, 
        1
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToPalette(
        'pages',
        'abstract',
        '--linebreak--,color',
        'after:abstract'
        
);

