$(document).ready(function() {
 
  $(".home-slider, .inner-slider").owlCarousel({
 
      navigation : true, // Show next and prev buttons
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      mouseDrag:true,
      autoPlay:true
  });

  $('.quick-enlarge').magnificPopup({
     delegate: 'a',
     type: 'image',
     tLoading: 'Loading image #%curr%...',
     mainClass: 'mfp-img-mobile',
     gallery: {
        enabled: true,
        navigateByImgClick: true,
        preload: [0,1] // Will preload 0 - before current, and 1 after the current image
     },
     image: {
        tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
        titleSrc: function(item) {
           return item.el.attr('title');
        }
     }
  });

  // setInterval(function(){
  //    $('.ani-1').addClass('full');
  // },1000)
  setInterval(function(){
     $('.ani-2').addClass('full-2');
  },1000)
  // setInterval(function(){
  //    $('.ani-3').addClass('full-3');
  // },3000)
  setInterval(function(){
     $('.ani-4').addClass('full-4');
  },2000)

  $( "table" ).wrap( "<div class='table-responsive'></div>" );

  setInterval(function(){
     $('.index-header-fix').addClass('index-header');
  },3000)

  setInterval(function(){
     $('.index-header-fix .navbar-right').addClass('fix-language');
  },4000)

  $(".navbar-toggle").click(function(){
    $(".header").toggleClass("header-bg");
    
    if($(".show-footer").length>0){
       $(".footer-show").removeClass("footer-cross");
       $( ".footer .col-md-6 ul" ).hide( "slow" );
    }else{
      $(".footer-show").show();
    }
    $("body").toggleClass("show-footer");
  });

  $( ".footer-show" ).click(function() {
    $(".footer-show").toggleClass("footer-cross");
    $( ".footer .col-md-6 ul" ).slideToggle( "slow" );
  });
  
  $(".home-slider .item").css('height',$( window ).height());
  $( window ).resize(function() {
    $(".home-slider .item").css('height',$( window ).height()); 
  });
 
});