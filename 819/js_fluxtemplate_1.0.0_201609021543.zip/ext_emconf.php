<?php

$EM_CONF[$_EXTKEY] = array(
	
	'title'				=> 'js_fluxtemplate',
	'description'		=> 'Fluid Power Extension',
	'category'			=> 'misc',
	'author'			=> 'jainish',
	'author_email'		=> 'jainishsenjaiya@gmail.com',
	'state'				=> 'misc',
	'internal'			=> '',
	'uploadfolder'		=> '0',
	'createDirs'		=> '',
	'clearCacheOnLoad'	=> 0,
	'version'			=> '1.0.0',

	'constraints'	=> array(
		'depends'	=> array(
			'flux'			=> '',
			'vhs'			=> '',
			'fluidcontent'	=> '',
			'fluidpages'	=> '',
		),
		'conflicts'	=> array(
		),
		'suggests'	=> array(
		),
	),
);