jQuery.noConflict();
jQuery(document).ready(function() {


jQuery('.ce-table').wrap('<div class="table-responsive"></div>');

jQuery("table").removeClass('ce-table');
jQuery("table").addClass('table');

    jQuery('.contact-icon').click(function() {
        jQuery("body").toggleClass('show-contact');
    });

    jQuery('.navbar-toggle').click(function() {
        if(jQuery(".navigation").hasClass('header-bg')) {
           jQuery(".navbar-collapse").slideUp('slow');
          setTimeout(function(){
            jQuery(".navigation").removeClass('header-bg');
            jQuery("body").removeClass('show-nav');
          }, 1000);
         
        } else {
          jQuery(".navigation").addClass('header-bg');
          jQuery("body").addClass('show-nav');
          jQuery(".navbar-collapse").slideDown('slow');
        }
    });

    jQuery('p').each(function() {
    var $this = jQuery(this);
    if($this.html().replace(/\s|&nbsp;/g, '').length == 0)
        $this.remove();
});

jQuery('.responsive-phone').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 2000,
        arrows: true,
        dots: false
    }); 

 

    function setHeight() {
        windowHeight = jQuery(window).innerHeight();
        jQuery('.grid-gallery').css('height', windowHeight);
    };
    setHeight();

    jQuery(window).resize(function() {
        setHeight();
    
    });

    jQuery('.center').slick({
  centerMode: true,
  centerPadding: '27%',
  slidesToShow: 1,
  responsive: [
    {
      breakpoint: 991,
      settings: {
        arrows: true,
        centerMode: true,
        centerPadding: '10%',
        slidesToShow: 1
      }
    },
    {
      breakpoint: 640,
      settings: {
        arrows: true,
        centerMode: true,
        centerPadding: '5%',
        slidesToShow: 1
      }
    }
  ]
});


jQuery('.responsive-news').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 3,
  slidesToScroll: 3,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});

jQuery('.slider').slick({
    infinite: true,
    dots: true,
    prevArrow: false,
    nextArrow: false,
  speed: 300,
    slidesToShow: 3,
    slidesToScroll: 3,
    rows: 3,

    responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 560,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]

});


    /******************* add remove class js *************************/

    jQuery(window).scroll(function() {
        if (jQuery(window).scrollTop() >= 50) {
            jQuery('.fixtop-header').addClass('fixed-header-bar');
        } else {
            jQuery('.fixtop-header').removeClass('fixed-header-bar');
        }

    });

});


// light box added by maunil


jQuery(".popup , .lightbox, .magnificpopup").magnificPopup({
  type: "image",
  tLoading: "Loading image #%curr%...",
  closeOnContentClick: true,
  closeBtnInside: true,
  fixedContentPos: false,
  mainClass: "mfp-no-margins mfp-with-zoom",
  image: {
      verticalFit: true
  },
  zoom: {
      enabled: true,
      duration: 300
  },
  gallery: {
      enabled: true,
      navigateByImgClick: true,
      preload: [ 0, 1 ]
  }
});
  jQuery(".csc-default table").addClass("table date-table table-hover");
  jQuery(".csc-default table").wrap('<div class="table-responsive"></div>');
  jQuery(".csc-textpic-imagecolumn").addClass("img-gallery");
  jQuery(".csc-textpic .table caption").each(function() {
    var a = jQuery(this).text();
    jQuery(this).closest(".popup").removeAttr("title");
    jQuery(this).closest(".popup").attr("title", "+a+");
});
// light box added by maunil

    /****************** add remove class js end ************************/

    

