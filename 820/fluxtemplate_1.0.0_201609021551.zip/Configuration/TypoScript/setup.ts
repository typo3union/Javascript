###
# The ROOT template. 
#
# This template will be called by the  template recored in the root page. It reads the root templates for every part, like page, menu, systemConfiguration and # extensionConfiguration.
###

# Include Page Template
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/fluid.ts">

# Include Config Template
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/config.ts">

# Include Menu Template
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/menu.ts">

# Include Blocks Template
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/content.ts">

# Include System Template
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/system.ts">

# Include Header-Data Template
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/header.ts">

# Include Extension Template
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/extensions.ts">