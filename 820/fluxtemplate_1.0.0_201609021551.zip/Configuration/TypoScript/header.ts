page.headTag = <head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /><link rel="icon" href="{$config.favicon}" type="image/ico; charset=binary">



page.includeCSS {
    
    bootstrap	= {$filepaths.css}bootstrap.min.css
    custom	    = {$filepaths.css}custom.css
    fontawesome	= {$filepaths.css}font-awesome.css
    popup       = {$filepaths.css}magnific-popup.css
     

    #googlefont	= https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,400italic
    #googlefont.external = 1
}


page.includeJS {
	jquery = {$filepaths.js}jquery.js
}

[browser = msie] && [version < 9]

	page.includeJSlibs {

		html5shiv	= https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js
		html5shiv.external = 1

		respond		= https://oss.maxcdn.com/respond/1.4.2/respond.min.js
		respond.external = 1
	}

[end]

page.includeJSFooterlibs {

	bootstrap	 = {$filepaths.js}bootstrap.min.js
	slick_min	 = {$filepaths.js}slick.min.js	
	grid 		 = {$filepaths.js}grid/modernizr.custom.js
	popup        = {$filepaths.js}jquery.magnific-popup.js
	common		 = {$filepaths.js}common.js
}


#page.headerData.9800 = TEXT  
#page.headerData.9800{
#	value (
#		<!-- Google Website Optimizer Control Script -->
#		
#		<script>
#			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
#			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
#			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
#			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
#
#			ga('create', '{$config.trackingID}', 'auto');
#			ga('send', 'pageview');
#
#		</script>
#
#		<!-- End of Google Website Optimizer Control Script -->
#	)
#}


[globalVar = TSFE:id = 1]

	page.headerData.9898 = TEXT  
	page.headerData.9898{
		value (
			<script>

				jQuery(document).ready(function(){
					jQuery('ul.nav li:first-child').addClass('active');
				});
				
			</script>
			)
	}

[end]