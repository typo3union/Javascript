###
# ALL CONSTANT
#
# Define whole website's Contatnt like menu, extension, config etc.,
###

config {

	# cat=config; type=boolean; label=Admin Panel: Turn on admin panel (mainly for testing purposes only)
	adminPanel		= 0
	
	# cat=config; type=boolean; label=Debugging: Turn on debugging (testing purposes only)
	debug			= 0	
	
	# cat=config; type=string; label=Absolute URI prefix: (use "/" if running on top level; use empty value to use relative URI)
	absRefPrefix 	= 

	# cat=config; type=string; label=Domain name for Base URL: (excluding slashes and protocol like http://)
	baseURL = pr820.in-entwicklung.info

	# cat=config; type=boolean; label=Real URL : Turn on realURL
	realURL = 1

	# cat=config; type=string; label=Favicon Icon : Favicon Icon Path
	favicon = typo3conf/ext/fluxtemplate/Resources/Public/Images/favicon.ico

	# cat=config; type=string; label= Google Analytics : Analytics tracking code
	trackingID = TRACK_ID

	# cat=config; type=string; label= Copyright : header line
	copyRightText = &copy; Tec-Folien-Allgäu

	# cat=config; type=string; label= Footer Logo
	footerLogo = typo3conf/ext/fluxtemplate/Resources/Public/Images/footer-logo.png

	# cat=config; type=string; label= Email Logo
	Emaillogo = typo3conf/ext/fluxtemplate/Resources/Public/Images/logo.jpg

}

config.pid {

	# cat= Storage ID; type=string; label= Main Navigation Page ID : 
	mainMenu = 1

	# cat=Storage ID; type=string; label= Footer Navigation Page ID : 
	footerMenu = 14
}

filepaths{

	# cat=fluxtemplate/filepaths; type=text; label=Pfad zu den Templates
	defaultTemplateRootPath	= typo3conf/ext/fluxtemplate/	

	# cat=fluxtemplate/filepaths; type=string; label=CSS: Location of the Cascading Style Sheets relative to site
	css						= typo3conf/ext/fluxtemplate/Resources/Public/Css/

	# cat=fluxtemplate/filepaths; type=string; label=Images: Location of the images relative to site
	images					= typo3conf/ext/fluxtemplate/Resources/Public/Images/

	# cat=fluxtemplate/filepaths; type=string; label=JS: Location of the Javascript files relative to site
	js						= typo3conf/ext/fluxtemplate/Resources/Public/Js/

	# cat=fluxtemplate/filepaths; type=string; label= Default TypoScript
	defaultTypoScript		= typo3conf/ext/fluxtemplate/Configuration/TypoScript/

	# cat=fluxtemplate/filepaths; type=string; label= Extension TypoScript
	extensionsTypoScript	= fluxtemplate/Configuration/TypoScript/Extensions/

	# cat=fluxtemplate/filepaths; type=string; label= Extension Template View Path
	extensionsView			= typo3conf/ext/fluxtemplate/Resources/Private/Templates/Extensions/
	
	# cat=fluxtemplate/filepaths; type=string; label= Extension Template CSS Path
	extensionsCss			= typo3conf/ext/fluxtemplate/Resources/Public/Extensions/

	# cat=fluxtemplate/filepaths; type=string; label= Private folder path
	private					= typo3conf/ext/fluxtemplate/Resources/Private/

	# cat=fluxtemplate/filepaths; type=string; label= Public folder path
	public					= typo3conf/ext/fluxtemplate/Resources/Public/
}


# cat=fluxtemplate/filepaths; type=boolean; label=Allow pages which have is_siteroot = 1 to inherit chosen template from parent. Disable this to prevent subsites in multisite environment from using the same template as the immediate parent of that site root.
plugin.tx_fluidpages.siteRootInheritance = 1

# This defines the maximum width of images inserted in content records of type Images or Text-with-images.
# There are seperate settings for images floated next to text (..InText)

styles.content {

	imgtext {
		maxW = 1000
		maxWInText = 1000
		borderThick = 1
		linkWrap.newWindow = 1
	}

	uploads {
		jumpurl_secure = 1
		jumpurl_secure_mimeTypes = pdf=application/pdf, doc=application/msword
		jumpurl = 1
	}

	imgtext.linkWrap.lightboxEnabled = 1
	imgtext.captionSplit = 1
}


### Please add in your constant for light-box here is not working :) 
#styles.content.textmedia.linkWrap.lightboxEnabled = 1
#styles.content.textmedia.linkWrap.lightboxCssClass = magnificpopup
#styles.content.textmedia.linkWrap.lightboxRelAttribute = magnificpopup[{field:uid}]
#plugin.tx_jhmagnificpopup.magnificpopup.support.user = .ce-textpic