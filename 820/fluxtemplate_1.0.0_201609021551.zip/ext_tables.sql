CREATE TABLE tx_news_domain_model_news (
        descriptionright text,
);