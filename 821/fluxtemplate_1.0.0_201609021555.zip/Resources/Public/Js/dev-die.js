$(document).ready(function() {
	
	//if( ($(window).width() > 1024 ) && ($(".header").is(':visible')) ) {
	if( $(".header").is(':visible') ) {	
		
		if( $(window).width() > 1024 ){
			var _getMenuHeight = $("#bs-example-navbar-collapse-1").height();
		}else{
			var _getMenuHeight = $(".navbar-header").height();
		}
		var _windowHeight = $( window ).height();

		$("main").css({"top": '-' + _getMenuHeight + "px" , "position" : "relative" , "background" : "#fff" , "z-index" : "10000"});

		$("#bs-example-navbar-collapse-1 li").hover(
		    function(e){
		    	$(".header").slideUp(600);
		    	setTimeout(function(){ $(".header").remove(); }, 601);
		    	$(".main-menu").addClass('sticky');
		    	$("main").css({"top": "0" , "position" : "static"});
		    }
		);
	}

	$(window).scroll(function () {
		var height =  $(window).scrollTop();
		if(height < 50){
			$(".main-menu").removeClass('sticky');	
		}else{
			$(".main-menu").addClass('sticky');
		}
		$(".header").slideUp(600);
    	setTimeout(function(){ $(".header").remove(); }, 601);
    	
    	$("main").css({"top": "0" , "position" : "static"});
    	if( $( window ).width() < 1024 ) {
			// $("#cloud-image").css({'margin-top':'89px'});
    	}else{
    		$("#cloud-image").css({'margin-top':'50px'});
    	}
	});
});