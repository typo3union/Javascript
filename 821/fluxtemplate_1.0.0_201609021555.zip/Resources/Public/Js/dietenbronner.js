$(document).ready(function() {
 
  $(".product-slider-small").owlCarousel({
    	autoPlay:false, //Set AutoPlay to 3 seconds
    	navigation:true,
    	pagination:false,
    	slideBy: 4,
      autoHeight:true,
 
      items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
      scrollPerPage : true
  });

  $(".product-slider-big").owlCarousel({
    	autoPlay:false, //Set AutoPlay to 3 seconds
    	navigation:true,
      autoHeight:true,
    	pagination:false,
      items : 6,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
      scrollPerPage : true
  });

  $(".product-view-slider").owlCarousel({ 
      navigation : true, // Show next and prev buttons
      slideSpeed : 300,
      autoPlay:false,
      autoHeight:true,
      pagination:false,
      paginationSpeed : 400,
      singleItem:true
  });

  $(".navbar-toggle").click(function(){
    $(".navbar-default").toggleClass("cross-arrow");
    $(".main-menu").toggleClass("fix-menu");
  });

  $("#ninja-slider").css('height',$( window ).height());
  $( window ).resize(function() {
    $("#ninja-slider").css('height',$( window ).height()); 
  });

  setInterval(function(){
     $('#ninja-slider-prev').addClass('next-prev');
     $('#ninja-slider-next').addClass('next-prev');
  },1000)
  setInterval(function(){
     $('#ninja-slider li').addClass('overlay');
  },1500)
  setInterval(function(){
     $('.caption').addClass('show-caption');
     $('.caption .btn').addClass('show-caption-btn');
  },2500)

 
});