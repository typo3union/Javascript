$(document).ready(function() {

	// magnific popup	
	$('.popup-gallery').magnificPopup({
		delegate: 'a.popup',
		type: 'image',
		tLoading: 'Loading image #%curr%...',
		mainClass: 'mfp-img-mobile',
		gallery: {
			enabled: true,
			navigateByImgClick: true,
			preload: [0,1] // Will preload 0 - before current, and 1 after the current image
		},
		image: {
			tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
			titleSrc: function(item) {
				return item.el.attr('title');
			}
		}
	});
	
	$('.quick-enlarge').magnificPopup({
		delegate: 'a.magnificpopup',
		type: 'image',
		tLoading: 'Loading image #%curr%...',
		mainClass: 'mfp-img-mobile',
		gallery: {
			enabled: true,
			navigateByImgClick: true,
			preload: [0,1] // Will preload 0 - before current, and 1 after the current image
		},
		image: {
			tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
			titleSrc: function(item) {
				return item.el.attr('title');
			}
		}
	});

	

	if( ($(window).width() > 1024 ) && ($(".body_id_1 .header").length > 1) ) {
		var _getMenuHeight = $("#bs-example-navbar-collapse-1").height();
		var _windowHeight = $( window ).height();

		$("main").css({"top": '-' + _getMenuHeight + "px" , "position" : "relative" , "background" : "#fff" , "z-index" : "10000"});

		/*$("#bs-example-navbar-collapse-1 li").hover(
			function(e){
				$(".header").slideUp(600);
				setTimeout(function(){ $(".header").remove(); }, 601);
				$(".main-menu").addClass('sticky');
				$("main").css({"top": "0" , "position" : "static"});
			}
		);*/
	}

	

	// On hover menu cloud image down.
	 cloudPosition();

	$( window ).resize(function() {
		 cloudPosition();		
	});

});

function cloudPosition(){

	if(!$("header").hasClass("header")){		
		if( $( window ).width() > 1024 ) {
			//$(".main-menu").addClass('sticky');
			$("#cloud-image").css({'margin-top':'50px'});
		}else{
			$(".main-menu").removeClass('sticky');
		}
	}

	if( $( window ).width() > 1024 ) {
			
		$("#bs-example-navbar-collapse-1 li.dropdown").hover(
			function(e){

				if( $( window ).width() > 1024 ) {
					
					$(this).addClass('hover-open');

					var _getDropdownLength = $(this).find('.dropdown-menu').height();

					var menuHeight = $(".main-menu").height();

					var height =  $(window).scrollTop();

					var totalDown = menuHeight+_getDropdownLength+height;

					$(".cloud-img-full").css({"top": _getDropdownLength + 20 + "px"}); 

					if( _getDropdownLength > 1) {
						if($(this).hasClass('hover-open')) {
							//$("#cloud-image > img ").hide();
							$("#cloud-image > img").css({"visibility":"hidden"});
						} else {
							//$("#cloud-image > img ").show();
							$("#cloud-image > img").css({"visibility":"visible"});
						}
					} else {			
						//$("#cloud-image > img ").show();
						$("#cloud-image > img").css({"visibility":"visible"});
					}
					

					

					/*if(height<340){
						if( _getDropdownLength > 1) {
							$("#cloud-image").css({"margin-top": totalDown + "px"});
						} else {			
							if($(this).hasClass('hover-open')) {
								$("#cloud-image").css({"margin-top": _getDropdownLength + "px"});
							} else {
								$("#cloud-image").css({'margin-top':'0'});
							}
						}
					}*/
				}
			}, // over
			function(e){ 
				$(this).removeClass('hover-open');
				$("#cloud-image").css({'margin-top':'50px'});
				//$("#cloud-image > img ").show();
				$("#cloud-image > img").css({"visibility":"visible"});
				var _getDropdownLength = $(this).find('.dropdown-menu').height();
				$(".cloud-img-full").css({"top": _getDropdownLength + 20 + "px"}); 
			}  // out
		);
	}
}