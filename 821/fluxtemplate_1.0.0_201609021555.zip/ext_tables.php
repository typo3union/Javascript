<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'Fluxtemplate: Website Template');

//# Add Constants and setup TSConfig
if ('BE' === TYPO3_MODE) {
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScript($_EXTKEY, 'constants', '<INCLUDE_TYPOSCRIPT: source="FILE:EXT:fluxtemplate/Configuration/TypoScript/constants.ts">');
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScript($_EXTKEY, 'setup', '<INCLUDE_TYPOSCRIPT: source="FILE:EXT:fluxtemplate/Configuration/TypoScript/setup.ts">');
}

//# Add page TSConfig
$pageTsConfig = \TYPO3\CMS\Core\Utility\GeneralUtility::getUrl(
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TsConfig/Page/config.ts');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig($pageTsConfig);

# Add user TSConfig
$userTsConfig = \TYPO3\CMS\Core\Utility\GeneralUtility::getUrl(
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TsConfig/User/config.ts');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addUserTSConfig($userTsConfig);

\FluidTYPO3\Flux\Core::registerProviderExtensionKey($_EXTKEY, 'Content');
\FluidTYPO3\Flux\Core::registerProviderExtensionKey($_EXTKEY, 'Page');


$thumbimage = array(
        'menuimage' => array (
                'exclude' => 0,
                'label' => 'Image :: Page Menu',
                'config' => array(
	                'type' => 'group',
	                'internal_type' => 'file',
	                'allowed' => 'gif,jpg,png,bmp',
	                'max_size' => 1000,
	                'uploadfolder' => 'uploads/pics/',
	                'show_thumbs' => 1,
	                'size' => 1,
	                'minitems' => 0,
	                'maxitems' => 1,
	                'autoSizeMax' => 1
        		)
        ),
        'menudesc' => array(
		    'exclude' => 0,
		        'label' => 'Descriptions :: Page Menu [ It will display only when there is no subpages]',
		        'config' => array(
		                'type' => 'text',
		                'cols' => 40,
		                'rows' => 6
		        ),
		        'defaultExtras' => 'richtext[]:rte_transform[mode=ts_css]'
		)
  	
);


\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns(
        'pages',        
        $thumbimage, 
        1
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToPalette(
        'pages',
        'abstract',
        '--linebreak--,menuimage,--linebreak--,menudesc',        
        'after:abstract'
        
);