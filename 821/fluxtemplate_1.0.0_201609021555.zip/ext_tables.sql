CREATE TABLE pages (
        menuimage text,
        menudesc text,
);