page.headTag = <head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /><link rel="icon" href="{$config.favicon}" type="image/ico; charset=binary">



page.includeCSS {
    ninja-slider  = {$filepaths.css}ninja-slider.css
    bootstrap	  = {$filepaths.css}bootstrap.min.css
    owl           = {$filepaths.css}owl.carousel.css
    owlTheme      = {$filepaths.css}owl.theme.css
    animate       = {$filepaths.css}animate.css
    dietenbronner = {$filepaths.css}dietenbronner.css
    custom        = {$filepaths.css}custom.css

    #googlefont	= https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,400italic
    #googlefont.external = 1
}


page.includeJS {
	jquery = {$filepaths.js}jquery.min-v1.12.4.js
}

page.includeJSFooterlibs {

	bootstrap	  = {$filepaths.js}bootstrap.min.js
	carousel	  = {$filepaths.js}owl.carousel.min.js
    ninjaVideo    = {$filepaths.js}ninjaVideoPlugin.js
    ninja-slider  = {$filepaths.js}ninja-slider.js
    dev-die       = {$filepaths.js}dev-die.js
	dietenbronner = {$filepaths.js}dietenbronner.js
    custom        = {$filepaths.js}custom.js
}
