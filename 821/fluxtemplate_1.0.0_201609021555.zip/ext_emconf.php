<?php

$EM_CONF[$_EXTKEY] = array(
	
	'title'				=> 'fluxtemplate',
	'description'		=> 'Fluid Power Extension',
	'category'			=> 'misc',
	'author'			=> 'deepak',
	'author_email'		=> 'deepakvisani@gmail.com',
	'state'				=> 'misc',
	'internal'			=> '',
	'uploadfolder'		=> '0',
	'createDirs'		=> '',
	'clearCacheOnLoad'	=> 0,
	'version'			=> '1.0.0',

	'constraints'	=> array(
		'depends'	=> array(
			'flux'			=> '',
			'vhs'			=> '',
			'fluidcontent'	=> '',
			'fluidpages'	=> '',
		),
		'conflicts'	=> array(
		),
		'suggests'	=> array(
		),
	),
);