<?php
namespace BMI\Bmi\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * BMIController
 */
class BMIController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * bMIRepository
	 *
	 * @var \BMI\Bmi\Domain\Repository\BMIRepository
	 * @inject
	 */
	protected $bMIRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {

		$GLOBALS['TSFE']->set_no_cache();

		$height = $_POST['tx_bmi_bmi']['height'];
		$weight = $_POST['tx_bmi_bmi']['weight'];
	
		$underweight = $this->settings['flexform']['underweight']; 
		$normalweight = $this->settings['flexform']['normalweight']; 
		$overweight = $this->settings['flexform']['overweight']; 
		$obesity = $this->settings['flexform']['obesity'];

		if($this->request->hasArgument('height') && $this->request->hasArgument('weight')){
			//BMI = ( Weight in Kilograms / ( Height in Meters x Height in Meters ) )
			$height = $height/100;
			$mheight = $height*$height;
			$BMI = ($weight / $mheight);
			$BMI =  number_format($BMI,2);

			if($BMI < $underweight){
				$result ='1';
			}
			else if($BMI > $underweight && $BMI < $normalweight){
				$result ='2';
			}
			else if($BMI > $normalweight && $BMI < $overweight){
				$result ='3';
			}
			else if($BMI > $obesity){
				$result ='4';
			}
			 $this->view->assign('result', $result);
			 $this->view->assign('BMI', $BMI);
		}

	}

	/**
	 * action show
	 *
	 * @param \BMI\Bmi\Domain\Model\BMI $bMI
	 * @return void
	 */
	public function showAction(\BMI\Bmi\Domain\Model\BMI $bMI) {
		$this->view->assign('bMI', $bMI);
	}

}