<?php
namespace JS\JsGreetingcards\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * GreetingCards
 */
class GreetingCards extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * title
	 *
	 * @var string
	 */
	protected $title = '';	

	/**
	 * image
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
	 */
	protected $image = NULL;

	/**
	 * smallimage
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
	 */
	protected $smallimage = NULL;

	/**
	 * Returns the image_bottom_text
	 *
	 * @return string $image_bottom_text
	 */
	protected $image_bottom_text = '';	

	/**
	 * title
	 *
	 * @var string
	 */

	public function getTitle() {
		return $this->title;
	}

	/**
	 * Sets the title
	 *
	 * @param string $title
	 * @return void
	 */
	public function setTitle($title) {
		$this->title = $title;
	}

	/**
	 * Returns the image
	 *
	 * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
	 */
	public function getImage() {
		return $this->image;
	}

	/**
	 * Sets the image
	 *
	 * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
	 * @return void
	 */
	public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image) {
		$this->image = $image;
	}

	/**
	 * image_bottom_text
	 *
	 * @var string
	 */
	public function getImageBottomText() {
		return $this->image_bottom_text;
	}

	/**
	 * Sets the image_bottom_text
	 *
	 * @param string $image_bottom_text
	 * @return void
	 */
	public function setImageBottomText($image_bottom_text) {
		$this->image_bottom_text = $image_bottom_text;
	}

	/**
	 * Returns the smallimage
	 *
	 * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $smallimage
	 */
	public function getSmallimage() {
		return $this->smallimage;
	}

	/**
	 * Sets the smallimage
	 *
	 * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $smallimage
	 * @return void
	 */
	public function setSmallimage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $smallimage) {
		$this->smallimage = $smallimage; 
	}


}