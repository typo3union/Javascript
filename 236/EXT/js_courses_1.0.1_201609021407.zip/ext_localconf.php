<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'JS.' . $_EXTKEY,
	'Courses',
	array(
		'Courses' => 'courses',
		
	),
	// non-cacheable actions
	array(
		'Courses' => 'courses',
		
	)
);

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'JS.' . $_EXTKEY,
	'Speaker',
	array(
		'Speaker' => 'speaker',
		
	),
	// non-cacheable actions
	array(
		'Speaker' => 'speaker',
		
	)
);
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder