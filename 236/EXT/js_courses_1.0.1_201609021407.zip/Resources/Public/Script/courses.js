/*
 *  (c) 2015 Jainish Senjaliya <jainish.online@gmail.com>
 *  All rights reserved 
*/

jQuery(document).ready(function() {

jQuery('#searchJob #klinik_select').change(function(){
    jQuery(".career-search .submit-icon").click();
});


var activeClinik = 	jQuery('.activeClinik').text();

if(activeClinik){
	jQuery("#klinik_select").val(activeClinik);		
}
	if(!jQuery('li.current').length > 0){
		jQuery('.pagination-section').remove();
	}
	
	function checkValidEmail(field) {
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (!filter.test(field.val())) {
			return false;
		}
		return true;
	}
	
	function len(value) {
		return value.val().length;
	}
	
	function trim(field){
		return jQuery.trim(field.val());	
	}
	
	jQuery('#js_courses').submit(function(event){
		
		var cValids = 0;
 			
		jQuery("#js_courses .validate").removeClass("error");
		jQuery("#js_courses .conditionError").hide();
		
		jQuery("#js_courses .validate").each(function(){
			if(jQuery(this).val()==''){
				jQuery(jQuery(this)).addClass("error");
				jQuery(this).attr("placeholder",jQuery(this).attr('mendatory_message'));
				cValids = 1;
			} 
		});

		if(cValids==0){
			if(!jQuery("#radios-4").is(":checked")){
				jQuery("#radios-4").addClass("error");
				jQuery("#js_courses .conditionError").show();
				cValids = 1;
			}
		}
		
		if(cValids == 0) { 
			jQuery(".formLoading").css("display","block");
		
		}else {
			//jQuery(".validateMessage").effect( "shake",{times:1}, 600 );
			return false;
		}
		
	});
	
	jQuery(".successMessage").delay(9000).hide(500);

});
