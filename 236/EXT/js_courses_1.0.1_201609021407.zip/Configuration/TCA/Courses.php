<?php
if (!defined ('TYPO3_MODE')) {
	die ('Access denied.');
}

$GLOBALS['TCA']['tx_jscourses_domain_model_courses'] = array(
	'ctrl' => $GLOBALS['TCA']['tx_jscourses_domain_model_courses']['ctrl'],
	'interface' => array(
		'showRecordFieldList' => 'sys_language_uid, l10n_parent, l10n_diffsource, hidden, title, subtitle, course_id, box_header, target_group, lessons, fortbildungs_point, prerequisites, availability, total_seat, fee, information, file, logo, category, occupational, event_date_period, speaker, guest_speakers, booking, organizers, available_seat_management',
	),
	'types' => array(
		'1' => array('showitem' => 'sys_language_uid;;;;1-1-1, l10n_parent, l10n_diffsource, hidden;;1, title, subtitle, course_id, box_header, target_group;;;richtext:rte_transform[mode=ts_links], lessons, fortbildungs_point, prerequisites, availability, total_seat, fee, information;;;richtext:rte_transform[mode=ts_links], file, logo, category, occupational, event_date_period, speaker, guest_speakers, booking, organizers, available_seat_management, --div--;LLL:EXT:cms/locallang_ttc.xlf:tabs.access, starttime, endtime'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(
	
		'sys_language_uid' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.language',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'sys_language',
				'foreign_table_where' => 'ORDER BY sys_language.title',
				'items' => array(
					array('LLL:EXT:lang/locallang_general.xlf:LGL.allLanguages', -1),
					array('LLL:EXT:lang/locallang_general.xlf:LGL.default_value', 0)
				),
			),
		),
		'l10n_parent' => array(
			'displayCond' => 'FIELD:sys_language_uid:>:0',
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.l18n_parent',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('', 0),
				),
				'foreign_table' => 'tx_jscourses_domain_model_courses',
				'foreign_table_where' => 'AND tx_jscourses_domain_model_courses.pid=###CURRENT_PID### AND tx_jscourses_domain_model_courses.sys_language_uid IN (-1,0)',
			),
		),
		'l10n_diffsource' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),

		't3ver_label' => array(
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.versionLabel',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'max' => 255,
			)
		),
	
		'hidden' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
			'config' => array(
				'type' => 'check',
			),
		),
		'starttime' => array(
			'exclude' => 1,
			'l10n_mode' => 'mergeIfNotBlank',
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.starttime',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0,
				'range' => array(
					'lower' => mktime(0, 0, 0, date('m'), date('d'), date('Y'))
				),
			),
		),
		'endtime' => array(
			'exclude' => 1,
			'l10n_mode' => 'mergeIfNotBlank',
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.endtime',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0,
				'range' => array(
					'lower' => mktime(0, 0, 0, date('m'), date('d'), date('Y'))
				),
			),
		),

		'title' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.title',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'subtitle' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.subtitle',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'course_id' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.course_id',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'box_header' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.box_header',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'target_group' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.target_group',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim',
				'wizards' => array(
					'RTE' => array(
						'icon' => 'wizard_rte2.gif',
						'notNewRecords'=> 1,
						'RTEonly' => 1,
						'script' => 'wizard_rte.php',
						'title' => 'LLL:EXT:cms/locallang_ttc.xlf:bodytext.W.RTE',
						'type' => 'script'
					)
				)
			),
		),
		'lessons' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.lessons',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			)
		),
		'fortbildungs_point' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.fortbildungs_point',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			)
		),
		'prerequisites' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.prerequisites',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			)
		),
		'availability' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.availability',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'total_seat' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.total_seat',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'fee' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.fee',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'information' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.information',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim',
				'wizards' => array(
					'RTE' => array(
						'icon' => 'wizard_rte2.gif',
						'notNewRecords'=> 1,
						'RTEonly' => 1,
						'script' => 'wizard_rte.php',
						'title' => 'LLL:EXT:cms/locallang_ttc.xlf:bodytext.W.RTE',
						'type' => 'script'
					)
				)
			),
		),
		'file' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.file',
			'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
				'file',
				array('maxitems' => 1),
				'*'
			),
		),
		'logo' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.logo',
			'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
				'logo',
				array('maxitems' => 1),
				$GLOBALS['TYPO3_CONF_VARS']['GFX']['imagefile_ext']
			),
		),
		'category' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.category',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_jscourses_domain_model_category',
				'MM' => 'tx_jscourses_courses_category_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'type' => 'popup',
						'title' => 'Edit',
						'script' => 'wizard_edit.php',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
					'add' => Array(
						'type' => 'script',
						'title' => 'Create new',
						'icon' => 'add.gif',
						'params' => array(
							'table' => 'tx_jscourses_domain_model_category',
							'pid' => '###CURRENT_PID###',
							'setValue' => 'prepend'
							),
						'script' => 'wizard_add.php',
					),
				),
			),
		),
		'occupational' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.occupational',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_jscourses_domain_model_occupational',
				'MM' => 'tx_jscourses_courses_occupational_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'type' => 'popup',
						'title' => 'Edit',
						'script' => 'wizard_edit.php',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
					'add' => Array(
						'type' => 'script',
						'title' => 'Create new',
						'icon' => 'add.gif',
						'params' => array(
							'table' => 'tx_jscourses_domain_model_occupational',
							'pid' => '###CURRENT_PID###',
							'setValue' => 'prepend'
							),
						'script' => 'wizard_add.php',
					),
				),
			),
		),
		'event_date_period' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.event_date_period',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_jscourses_domain_model_event',
				'foreign_field' => 'courses',
				'maxitems'      => 9999,
				'appearance' => array(
					'collapseAll' => 0,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		'speaker' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.speaker',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_jscourses_domain_model_speaker',
				'MM' => 'tx_jscourses_courses_speaker_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'type' => 'popup',
						'title' => 'Edit',
						'script' => 'wizard_edit.php',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
					'add' => Array(
						'type' => 'script',
						'title' => 'Create new',
						'icon' => 'add.gif',
						'params' => array(
							'table' => 'tx_jscourses_domain_model_speaker',
							'pid' => '###CURRENT_PID###',
							'setValue' => 'prepend'
							),
						'script' => 'wizard_add.php',
					),
				),
			),
		),
		'guest_speakers' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.guest_speakers',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_jscourses_domain_model_speaker',
				'MM' => 'tx_jscourses_courses_guestspeakers_speaker_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'type' => 'popup',
						'title' => 'Edit',
						'script' => 'wizard_edit.php',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
					'add' => Array(
						'type' => 'script',
						'title' => 'Create new',
						'icon' => 'add.gif',
						'params' => array(
							'table' => 'tx_jscourses_domain_model_speaker',
							'pid' => '###CURRENT_PID###',
							'setValue' => 'prepend'
							),
						'script' => 'wizard_add.php',
					),
				),
			),
		),
		'booking' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.booking',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_jscourses_domain_model_booking',
				'foreign_field' => 'courses',
				'maxitems'      => 9999,
				'appearance' => array(
					'collapseAll' => 0,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		'organizers' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.organizers',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_jscourses_domain_model_organizers',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'available_seat_management' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_courses.available_seat_management',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_jscourses_domain_model_availableseat',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		
	),
);
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['types']['1']['showitem'] = 'sys_language_uid;;;;1-1-1, l10n_parent, l10n_diffsource, hidden;;1, title, subtitle, course_id, box_header, target_group;;;richtext:rte_transform[mode=ts_links], lessons, fortbildungs_point, prerequisites, availability, fee, information;;;richtext:rte_transform[mode=ts_links], file, logo, category, occupational,organizers, available_seat_management, event_date_period, speaker, guest_speakers, --div--;Buchungsliste, booking , --div--;LLL:EXT:cms/locallang_ttc.xlf:tabs.access, starttime, endtime';

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['event_date_period']['config']['maxitems'] = 4;

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['lessons']['config']['rows'] = 5;
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['fortbildungs_point']['config']['rows'] = 5;
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['prerequisites']['config']['rows'] = 5;

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['file']['config'] = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
				'file',
				array('maxitems' => 1),
				'PDF'
			);

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['title']['config']['eval'] = 'required, trim';

$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['category']['config']['foreign_table_where'] = 'AND tx_jscourses_domain_model_category.pid=###CURRENT_PID### AND tx_jscourses_domain_model_category.sys_language_uid IN (-1,0)';
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['occupational']['config']['foreign_table_where'] = 'AND tx_jscourses_domain_model_occupational.pid=###CURRENT_PID### AND tx_jscourses_domain_model_occupational.sys_language_uid IN (-1,0)';
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['speaker']['config']['foreign_table_where'] = 'AND tx_jscourses_domain_model_speaker.pid=###CURRENT_PID### AND tx_jscourses_domain_model_speaker.sys_language_uid IN (-1,0)';
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['guest_speakers']['config']['foreign_table_where'] = 'AND tx_jscourses_domain_model_speaker.pid=###CURRENT_PID### AND tx_jscourses_domain_model_speaker.sys_language_uid IN (-1,0)';
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['organizers']['config']['foreign_table_where'] = 'AND tx_jscourses_domain_model_organizers.pid=###CURRENT_PID### AND tx_jscourses_domain_model_organizers.sys_language_uid IN (-1,0)';
$GLOBALS['TCA']['tx_jscourses_domain_model_courses']['columns']['available_seat_management']['config']['foreign_table_where'] = 'AND tx_jscourses_domain_model_availableseat.pid=###CURRENT_PID### AND tx_jscourses_domain_model_availableseat.sys_language_uid IN (-1,0)';