<?php
if (!defined ('TYPO3_MODE')) {
	die ('Access denied.');
}

$GLOBALS['TCA']['tx_jscourses_domain_model_booking'] = array(
	'ctrl' => $GLOBALS['TCA']['tx_jscourses_domain_model_booking']['ctrl'],
	'interface' => array(
		'showRecordFieldList' => 'sys_language_uid, l10n_parent, l10n_diffsource, hidden, salutation, title, name, last_name, dob, occupation, street, housenumber, zip, place, country, work_phone, private_phone, fax, email, billing_address, other_messages, booked_course_in_waiting_list, different_billing_address, training_newsletter, accommodations, current_training_program_by_mail, current_training_program_by_email',
	),
	'types' => array(
		'1' => array('showitem' => 'sys_language_uid;;;;1-1-1, l10n_parent, l10n_diffsource, hidden;;1, salutation, title, name, last_name, dob, occupation, street, housenumber, zip, place, country, work_phone, private_phone, fax, email, billing_address, other_messages, booked_course_in_waiting_list, different_billing_address, training_newsletter, accommodations, current_training_program_by_mail, current_training_program_by_email, --div--;LLL:EXT:cms/locallang_ttc.xlf:tabs.access, starttime, endtime'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(
	
		'sys_language_uid' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.language',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'sys_language',
				'foreign_table_where' => 'ORDER BY sys_language.title',
				'items' => array(
					array('LLL:EXT:lang/locallang_general.xlf:LGL.allLanguages', -1),
					array('LLL:EXT:lang/locallang_general.xlf:LGL.default_value', 0)
				),
			),
		),
		'l10n_parent' => array(
			'displayCond' => 'FIELD:sys_language_uid:>:0',
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.l18n_parent',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('', 0),
				),
				'foreign_table' => 'tx_jscourses_domain_model_booking',
				'foreign_table_where' => 'AND tx_jscourses_domain_model_booking.pid=###CURRENT_PID### AND tx_jscourses_domain_model_booking.sys_language_uid IN (-1,0)',
			),
		),
		'l10n_diffsource' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),

		't3ver_label' => array(
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.versionLabel',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'max' => 255,
			)
		),
	
		'hidden' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
			'config' => array(
				'type' => 'check',
			),
		),
		'starttime' => array(
			'exclude' => 1,
			'l10n_mode' => 'mergeIfNotBlank',
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.starttime',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0,
				'range' => array(
					'lower' => mktime(0, 0, 0, date('m'), date('d'), date('Y'))
				),
			),
		),
		'endtime' => array(
			'exclude' => 1,
			'l10n_mode' => 'mergeIfNotBlank',
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.endtime',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0,
				'range' => array(
					'lower' => mktime(0, 0, 0, date('m'), date('d'), date('Y'))
				),
			),
		),

		'salutation' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.salutation',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('-- Label --', 0),
				),
				'size' => 1,
				'maxitems' => 1,
				'eval' => ''
			),
		),
		'title' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.title',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'name' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.name',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'last_name' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.last_name',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'dob' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.dob',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'occupation' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.occupation',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'street' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.street',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'housenumber' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.housenumber',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'zip' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.zip',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'place' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.place',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'country' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.country',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'work_phone' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.work_phone',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'private_phone' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.private_phone',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'fax' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.fax',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'email' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.email',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'billing_address' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.billing_address',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			)
		),
		'other_messages' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.other_messages',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			)
		),
		'booked_course_in_waiting_list' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.booked_course_in_waiting_list',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'different_billing_address' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.different_billing_address',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'training_newsletter' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.training_newsletter',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'accommodations' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.accommodations',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'current_training_program_by_mail' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.current_training_program_by_mail',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'current_training_program_by_email' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.current_training_program_by_email',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		
		'courses' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder

$GLOBALS['TCA']['tx_jscourses_domain_model_booking']['types']['1']['showitem'] = 'sys_language_uid;;;;1-1-1, l10n_parent, l10n_diffsource, hidden;;1, salutation, title, name, last_name, occupation, street, housenumber, zip, place, country, work_phone, private_phone, email, billing_address, other_messages, booked_course_in_waiting_list, different_billing_address, --div--;LLL:EXT:cms/locallang_ttc.xlf:tabs.access, starttime, endtime';

$GLOBALS['TCA']['tx_jscourses_domain_model_booking']['columns']['salutation']['config']['items'] =  array(
					array('LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.salutation.I.0', 0),
					array('LLL:EXT:js_courses/Resources/Private/Language/locallang_db.xlf:tx_jscourses_domain_model_booking.salutation.I.1', 1),
				);