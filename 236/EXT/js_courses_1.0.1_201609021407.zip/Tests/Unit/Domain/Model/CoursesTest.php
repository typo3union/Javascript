<?php

namespace JS\JsCourses\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Jainish Senjaliya <jainishsenjaliya@gmail.com>
 *           Jainish Senjaliya <jainishsenjaliya@gmail.com>
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \JS\JsCourses\Domain\Model\Courses.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Jainish Senjaliya <jainishsenjaliya@gmail.com>
 * @author Jainish Senjaliya <jainishsenjaliya@gmail.com>
 */
class CoursesTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {
	/**
	 * @var \JS\JsCourses\Domain\Model\Courses
	 */
	protected $subject = NULL;

	protected function setUp() {
		$this->subject = new \JS\JsCourses\Domain\Model\Courses();
	}

	protected function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getTitleReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getTitle()
		);
	}

	/**
	 * @test
	 */
	public function setTitleForStringSetsTitle() {
		$this->subject->setTitle('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'title',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getSubtitleReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getSubtitle()
		);
	}

	/**
	 * @test
	 */
	public function setSubtitleForStringSetsSubtitle() {
		$this->subject->setSubtitle('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'subtitle',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCourseIdReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getCourseId()
		);
	}

	/**
	 * @test
	 */
	public function setCourseIdForStringSetsCourseId() {
		$this->subject->setCourseId('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'courseId',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getBoxHeaderReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getBoxHeader()
		);
	}

	/**
	 * @test
	 */
	public function setBoxHeaderForStringSetsBoxHeader() {
		$this->subject->setBoxHeader('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'boxHeader',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getTargetGroupReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getTargetGroup()
		);
	}

	/**
	 * @test
	 */
	public function setTargetGroupForStringSetsTargetGroup() {
		$this->subject->setTargetGroup('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'targetGroup',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getLessonsReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getLessons()
		);
	}

	/**
	 * @test
	 */
	public function setLessonsForStringSetsLessons() {
		$this->subject->setLessons('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'lessons',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFortbildungsPointReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getFortbildungsPoint()
		);
	}

	/**
	 * @test
	 */
	public function setFortbildungsPointForStringSetsFortbildungsPoint() {
		$this->subject->setFortbildungsPoint('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'fortbildungsPoint',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPrerequisitesReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getPrerequisites()
		);
	}

	/**
	 * @test
	 */
	public function setPrerequisitesForStringSetsPrerequisites() {
		$this->subject->setPrerequisites('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'prerequisites',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getAvailabilityReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getAvailability()
		);
	}

	/**
	 * @test
	 */
	public function setAvailabilityForStringSetsAvailability() {
		$this->subject->setAvailability('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'availability',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getTotalSeatReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getTotalSeat()
		);
	}

	/**
	 * @test
	 */
	public function setTotalSeatForStringSetsTotalSeat() {
		$this->subject->setTotalSeat('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'totalSeat',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFeeReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getFee()
		);
	}

	/**
	 * @test
	 */
	public function setFeeForStringSetsFee() {
		$this->subject->setFee('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'fee',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getInformationReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getInformation()
		);
	}

	/**
	 * @test
	 */
	public function setInformationForStringSetsInformation() {
		$this->subject->setInformation('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'information',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFileReturnsInitialValueForFileReference() {
		$this->assertEquals(
			NULL,
			$this->subject->getFile()
		);
	}

	/**
	 * @test
	 */
	public function setFileForFileReferenceSetsFile() {
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setFile($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'file',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getLogoReturnsInitialValueForFileReference() {
		$this->assertEquals(
			NULL,
			$this->subject->getLogo()
		);
	}

	/**
	 * @test
	 */
	public function setLogoForFileReferenceSetsLogo() {
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setLogo($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'logo',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCategoryReturnsInitialValueForCategory() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getCategory()
		);
	}

	/**
	 * @test
	 */
	public function setCategoryForObjectStorageContainingCategorySetsCategory() {
		$category = new \JS\JsCourses\Domain\Model\Category();
		$objectStorageHoldingExactlyOneCategory = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneCategory->attach($category);
		$this->subject->setCategory($objectStorageHoldingExactlyOneCategory);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneCategory,
			'category',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addCategoryToObjectStorageHoldingCategory() {
		$category = new \JS\JsCourses\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->addCategory($category);
	}

	/**
	 * @test
	 */
	public function removeCategoryFromObjectStorageHoldingCategory() {
		$category = new \JS\JsCourses\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->removeCategory($category);

	}

	/**
	 * @test
	 */
	public function getOccupationalReturnsInitialValueForOccupational() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getOccupational()
		);
	}

	/**
	 * @test
	 */
	public function setOccupationalForObjectStorageContainingOccupationalSetsOccupational() {
		$occupational = new \JS\JsCourses\Domain\Model\Occupational();
		$objectStorageHoldingExactlyOneOccupational = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneOccupational->attach($occupational);
		$this->subject->setOccupational($objectStorageHoldingExactlyOneOccupational);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneOccupational,
			'occupational',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addOccupationalToObjectStorageHoldingOccupational() {
		$occupational = new \JS\JsCourses\Domain\Model\Occupational();
		$occupationalObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$occupationalObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($occupational));
		$this->inject($this->subject, 'occupational', $occupationalObjectStorageMock);

		$this->subject->addOccupational($occupational);
	}

	/**
	 * @test
	 */
	public function removeOccupationalFromObjectStorageHoldingOccupational() {
		$occupational = new \JS\JsCourses\Domain\Model\Occupational();
		$occupationalObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$occupationalObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($occupational));
		$this->inject($this->subject, 'occupational', $occupationalObjectStorageMock);

		$this->subject->removeOccupational($occupational);

	}

	/**
	 * @test
	 */
	public function getEventDatePeriodReturnsInitialValueForEvent() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getEventDatePeriod()
		);
	}

	/**
	 * @test
	 */
	public function setEventDatePeriodForObjectStorageContainingEventSetsEventDatePeriod() {
		$eventDatePeriod = new \JS\JsCourses\Domain\Model\Event();
		$objectStorageHoldingExactlyOneEventDatePeriod = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneEventDatePeriod->attach($eventDatePeriod);
		$this->subject->setEventDatePeriod($objectStorageHoldingExactlyOneEventDatePeriod);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneEventDatePeriod,
			'eventDatePeriod',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addEventDatePeriodToObjectStorageHoldingEventDatePeriod() {
		$eventDatePeriod = new \JS\JsCourses\Domain\Model\Event();
		$eventDatePeriodObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$eventDatePeriodObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($eventDatePeriod));
		$this->inject($this->subject, 'eventDatePeriod', $eventDatePeriodObjectStorageMock);

		$this->subject->addEventDatePeriod($eventDatePeriod);
	}

	/**
	 * @test
	 */
	public function removeEventDatePeriodFromObjectStorageHoldingEventDatePeriod() {
		$eventDatePeriod = new \JS\JsCourses\Domain\Model\Event();
		$eventDatePeriodObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$eventDatePeriodObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($eventDatePeriod));
		$this->inject($this->subject, 'eventDatePeriod', $eventDatePeriodObjectStorageMock);

		$this->subject->removeEventDatePeriod($eventDatePeriod);

	}

	/**
	 * @test
	 */
	public function getSpeakerReturnsInitialValueForSpeaker() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getSpeaker()
		);
	}

	/**
	 * @test
	 */
	public function setSpeakerForObjectStorageContainingSpeakerSetsSpeaker() {
		$speaker = new \JS\JsCourses\Domain\Model\Speaker();
		$objectStorageHoldingExactlyOneSpeaker = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneSpeaker->attach($speaker);
		$this->subject->setSpeaker($objectStorageHoldingExactlyOneSpeaker);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneSpeaker,
			'speaker',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addSpeakerToObjectStorageHoldingSpeaker() {
		$speaker = new \JS\JsCourses\Domain\Model\Speaker();
		$speakerObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$speakerObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($speaker));
		$this->inject($this->subject, 'speaker', $speakerObjectStorageMock);

		$this->subject->addSpeaker($speaker);
	}

	/**
	 * @test
	 */
	public function removeSpeakerFromObjectStorageHoldingSpeaker() {
		$speaker = new \JS\JsCourses\Domain\Model\Speaker();
		$speakerObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$speakerObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($speaker));
		$this->inject($this->subject, 'speaker', $speakerObjectStorageMock);

		$this->subject->removeSpeaker($speaker);

	}

	/**
	 * @test
	 */
	public function getGuestSpeakersReturnsInitialValueForSpeaker() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getGuestSpeakers()
		);
	}

	/**
	 * @test
	 */
	public function setGuestSpeakersForObjectStorageContainingSpeakerSetsGuestSpeakers() {
		$guestSpeaker = new \JS\JsCourses\Domain\Model\Speaker();
		$objectStorageHoldingExactlyOneGuestSpeakers = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneGuestSpeakers->attach($guestSpeaker);
		$this->subject->setGuestSpeakers($objectStorageHoldingExactlyOneGuestSpeakers);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneGuestSpeakers,
			'guestSpeakers',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addGuestSpeakerToObjectStorageHoldingGuestSpeakers() {
		$guestSpeaker = new \JS\JsCourses\Domain\Model\Speaker();
		$guestSpeakersObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$guestSpeakersObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($guestSpeaker));
		$this->inject($this->subject, 'guestSpeakers', $guestSpeakersObjectStorageMock);

		$this->subject->addGuestSpeaker($guestSpeaker);
	}

	/**
	 * @test
	 */
	public function removeGuestSpeakerFromObjectStorageHoldingGuestSpeakers() {
		$guestSpeaker = new \JS\JsCourses\Domain\Model\Speaker();
		$guestSpeakersObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$guestSpeakersObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($guestSpeaker));
		$this->inject($this->subject, 'guestSpeakers', $guestSpeakersObjectStorageMock);

		$this->subject->removeGuestSpeaker($guestSpeaker);

	}

	/**
	 * @test
	 */
	public function getBookingReturnsInitialValueForBooking() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getBooking()
		);
	}

	/**
	 * @test
	 */
	public function setBookingForObjectStorageContainingBookingSetsBooking() {
		$booking = new \JS\JsCourses\Domain\Model\Booking();
		$objectStorageHoldingExactlyOneBooking = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneBooking->attach($booking);
		$this->subject->setBooking($objectStorageHoldingExactlyOneBooking);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneBooking,
			'booking',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addBookingToObjectStorageHoldingBooking() {
		$booking = new \JS\JsCourses\Domain\Model\Booking();
		$bookingObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$bookingObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($booking));
		$this->inject($this->subject, 'booking', $bookingObjectStorageMock);

		$this->subject->addBooking($booking);
	}

	/**
	 * @test
	 */
	public function removeBookingFromObjectStorageHoldingBooking() {
		$booking = new \JS\JsCourses\Domain\Model\Booking();
		$bookingObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$bookingObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($booking));
		$this->inject($this->subject, 'booking', $bookingObjectStorageMock);

		$this->subject->removeBooking($booking);

	}

	/**
	 * @test
	 */
	public function getOrganizersReturnsInitialValueForOrganizers() {
		$this->assertEquals(
			NULL,
			$this->subject->getOrganizers()
		);
	}

	/**
	 * @test
	 */
	public function setOrganizersForOrganizersSetsOrganizers() {
		$organizersFixture = new \JS\JsCourses\Domain\Model\Organizers();
		$this->subject->setOrganizers($organizersFixture);

		$this->assertAttributeEquals(
			$organizersFixture,
			'organizers',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getAvailableSeatManagementReturnsInitialValueForAvailableSeat() {
		$this->assertEquals(
			NULL,
			$this->subject->getAvailableSeatManagement()
		);
	}

	/**
	 * @test
	 */
	public function setAvailableSeatManagementForAvailableSeatSetsAvailableSeatManagement() {
		$availableSeatManagementFixture = new \JS\JsCourses\Domain\Model\AvailableSeat();
		$this->subject->setAvailableSeatManagement($availableSeatManagementFixture);

		$this->assertAttributeEquals(
			$availableSeatManagementFixture,
			'availableSeatManagement',
			$this->subject
		);
	}
}
