<?php
namespace JS\JsCourses\Controller;

session_start();

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * CoursesController
 */
class CoursesController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * coursesService
	 *
	 * @var \JS\JsCourses\Service\CoursesService
	 * @inject
	 */
	protected $coursesService = NULL;

	/**
	 * coursesRepository
	 *
	 * @var \JS\JsCourses\Domain\Repository\CoursesRepository
	 * @inject
	 */
	protected $coursesRepository = NULL;

	/**
	 * action courses
	 *
	 * @return void
	 */
	public function coursesAction() {
		
		$GLOBALS['TSFE']->set_no_cache();

		$template = '0';

		$success = $errors ="";
		
		$this->settings['fullURL'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getIndpEnv('TYPO3_SITE_URL');
		$this->settings['cObject'] = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('tslib_cObj');
		
		$uriParams = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET();

		if (isset($_SESSION['successMessage'])) {
			$success = $_SESSION['successMessage'];
			unset($_SESSION['successMessage']);
		}
		if (isset($_SESSION['errorMessage'])) {
			$errors = $_SESSION['errorMessage'];
			unset($_SESSION['errorMessage']);
		}

 		if ($this->request->hasArgument('bookCourses')) {

			$book = $this->request->getArguments();

			$res  = $this->coursesService->insertUserData($book,$this->settings['storagePID']);

			if($res==1){

				$formFields = $this->request->getArguments();

				$arr = array('salutation'	=> $formFields['salutation'],
							 'title' 		=> $formFields['title'],
							 'name' 		=> $formFields['name'],
							 'last_name' 	=> $formFields['last_name'],
							 'occupation' 	=> $formFields['occupation'],
							 'street' 		=> $formFields['street'],
							 'housenumber'	=> $formFields['housenumber'],
							 'zip' 			=> $formFields['zip'],
							 'place' 		=> $formFields['place'],
							 'country' 		=> $formFields['country'],
							 'work_phone'	=> $formFields['work_phone'],
							 'private_phone'=> $formFields['private_phone'],
							 'email' 		=> $formFields['email'],

							 'billing_address' 		=> $formFields['billing_address'],
							 'other_messages' 		=> $formFields['other_messages'],

							 'booked_course_in_waiting_list'	=> $formFields['booked_course_in_waiting_list'],
							 'form.different_billing_address' 	=> $formFields['different_billing_address'],

							);


				foreach ($arr as $key => $value) {
					if($value!=""){
						$mailFields['mail'][] = array('field'=>$key,'value'=>$value); 
					}
				}

				$userContent = $this->objectManager->get('TYPO3\\CMS\\Fluid\\View\\StandaloneView');

				$templateName = 'Email/userContent.html';

				$extbaseFrameworkConfiguration = $this->configurationManager->getConfiguration(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FRAMEWORK);

				$templateRootPath = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($extbaseFrameworkConfiguration['view']['templateRootPath']);

				$templatePathAndFilename = $templateRootPath.$templateName;

				$userContent->setTemplatePathAndFilename($templatePathAndFilename);

				$userContent->assignMultiple($mailFields);
				
				$userContents = $userContent->render();

				$returnPath = $attachements = $plain =  $bccName = $bccEmail = "";

				$adminEmail			=  $this->settings['flexform']['receiver']['email'];

				if($adminEmail!=""){

					$adminName			=  $this->settings['flexform']['receiver']['name'];
					$adminEmail			=  $this->settings['flexform']['receiver']['email'];
					$subject			=  $this->settings['flexform']['receiver']['subject'];
					$senderName			=  $this->settings['flexform']['receiver']['senderName'];
					$senderEmail		=  $this->settings['flexform']['receiver']['senderEmail'];
					$replyToName		=  $this->settings['flexform']['receiver']['replyToName'];
					$replyToEmail		=  $this->settings['flexform']['receiver']['replyToEmail'];

					$txt = $this->settings['admin'];
					
					$emailBody = nl2br(nl2br(html_entity_decode($txt, ENT_QUOTES)));

					$emailBody = str_replace("{userContent}", $userContents, $emailBody);

					$toArr = array(0=>array("name"=>$adminName,"email"=>$adminEmail));

					$this->coursesService->sendMail($toArr, $subject, $emailBody, $plain, $senderEmail, $senderName, $replyToEmail, $replyToName, $bccName, $bccEmail, $returnPath, $attachements);
				}


				if($book['email']!=""){

					$name = $book['name']." ".$book['last_name'];

					$subject			=  $this->settings['flexform']['receiver']['subject'];
					$senderName			=  $this->settings['flexform']['receiver']['senderName'];
					$senderEmail		=  $this->settings['flexform']['receiver']['senderEmail'];
					$replyToName		=  $this->settings['flexform']['receiver']['replyToName'];
					$replyToEmail		=  $this->settings['flexform']['receiver']['replyToEmail'];

					$txt = $this->settings['user'];
				   	$msg = nl2br(nl2br(html_entity_decode($txt, ENT_QUOTES)));

					$emailBody	= str_replace("{username}", $name, $msg);

					$emailBody = str_replace("{userContent}", $userContents, $emailBody);

					$toArr = array(0=>array("name"=>$name,"email"=>$book['email']));

					$this->coursesService->sendMail($toArr, $subject, $emailBody, $plain, $senderEmail, $senderName, $replyToEmail, $replyToName, $bccName, $bccEmail, $returnPath, $attachements);
				}

				$_SESSION['successMessage'] = "booked";

				$additionalParams = '&tx_jscourses_courses[uid]='.$book['book'];

				$this->redirectURL($this->settings['cObject'],$GLOBALS['TSFE']->id,$this->settings['fullURL'],$additionalParams);

			}else{
				$_SESSION['errorMessage'] = "notbooked";
			}

		}else if ($this->request->hasArgument('searchCourses')) {

			$search = $this->request->getArguments();

			$additionalParams =	"";

			$additionalParams .= $search['course_id']==""?"":"&tx_jscourses_courses[id]=".trim($search['course_id']);
			$additionalParams .= $search['title']==""?"":"&tx_jscourses_courses[title]=".trim($search['title']);
			$additionalParams .= $search['category']==""?"":"&tx_jscourses_courses[category]=".$search['category'];
			$additionalParams .= $search['occupational']==""?"":"&tx_jscourses_courses[occupational]=".$search['occupational'];
			$additionalParams .= $search['speaker']==""?"":"&tx_jscourses_courses[speaker]=".$search['speaker'];
			$additionalParams .= "&q=1";

			$this->redirectURL($this->settings['cObject'],$GLOBALS['TSFE']->id,$this->settings['fullURL'],$additionalParams);
		}


		$category = $occupational = $speaker = '';

		$arr = array();


		if ($this->request->hasArgument('uid')) {

			$arr = $this->request->getArguments();

			$uid = $arr['uid'];

			$template = '1';

			$courseBrowserTitle  = $this->coursesRepository->getCoursesTitle($uid);
			if($courseBrowserTitle){
				$GLOBALS['TSFE']->page['title'] = $courseBrowserTitle[0]['title'];	
			}

		} else if ($this->request->hasArgument('book')) {

			$book = $this->request->getArguments();

			$uid = $book['book'];

			$template = '2';

		}else{

			$category = $this->coursesRepository->getCategoryList($this->settings);

			$occupational = $this->coursesRepository->getOccupationalList($this->settings);

			$speaker = $this->coursesRepository->getSpeakerList($this->settings);
		}

		$search = $this->request->getArguments();

		$searhArr = array();

		if(isset($_GET['q']) && $_GET['q']==1){

			$searhArr['title']			= trim($search['title']);
			$searhArr['course_id']		= trim($search['id']);
			$searhArr['occupational']	= trim($search['occupational']);
			$searhArr['category']		= trim($search['category']);
			$searhArr['speaker']		= trim($search['speaker']);
			
		}else{
			$searhArr['title'] = $searhArr['course_id'] = $searhArr['occupational'] = $searhArr['category'] = $searhArr['speaker'] = "";
		}

		$courses = $this->coursesRepository->getCourses($this->settings, $uid, $search,$arr);

		$this->view->assign('template', $template);
		$this->view->assign('category', $category);
		$this->view->assign('occupational', $occupational);
		$this->view->assign('speaker', $speaker);
		$this->view->assign('errors', $errors);
		$this->view->assign('success', $success);
		$this->view->assign('courses', $courses);
		$this->view->assign('uriParams', $uriParams);

		$this->view->assign('search', $searhArr);

		// Include Additional Data
		$this->coursesService->includeAdditionalData($this->settings);
	}

	/**
	 * redirectURL
	 *
	 * @param $cObject
	 * @param $pid
	 * @param $fullURL
	 * @param $additionalParams
	 * @return
	 */
	public function redirectURL($cObject, $pid, $fullURL, $additionalParams = "") {
			
			$configurations['additionalParams'] = $additionalParams;
			$configurations['returnLast'] = 'url'; // get it as URL
			$configurations['parameter'] = $pid;
			$url  = $fullURL.$cObject->typolink(NULL, $configurations);

			header("Location:".$url);
			die;
	}

}