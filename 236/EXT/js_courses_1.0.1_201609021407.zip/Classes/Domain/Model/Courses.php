<?php
namespace JS\JsCourses\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Courses
 */
class Courses extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * title
	 *
	 * @var string
	 */
	protected $title = '';

	/**
	 * subtitle
	 *
	 * @var string
	 */
	protected $subtitle = '';

	/**
	 * courseId
	 *
	 * @var string
	 */
	protected $courseId = '';

	/**
	 * boxHeader
	 *
	 * @var string
	 */
	protected $boxHeader = '';

	/**
	 * targetGroup
	 *
	 * @var string
	 */
	protected $targetGroup = '';

	/**
	 * lessons
	 *
	 * @var string
	 */
	protected $lessons = '';

	/**
	 * fortbildungsPoint
	 *
	 * @var string
	 */
	protected $fortbildungsPoint = '';

	/**
	 * prerequisites
	 *
	 * @var string
	 */
	protected $prerequisites = '';

	/**
	 * availability
	 *
	 * @var string
	 */
	protected $availability = '';

	/**
	 * totalSeat
	 *
	 * @var string
	 */
	protected $totalSeat = '';

	/**
	 * fee
	 *
	 * @var string
	 */
	protected $fee = '';

	/**
	 * information
	 *
	 * @var string
	 */
	protected $information = '';

	/**
	 * file
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
	 */
	protected $file = NULL;

	/**
	 * logo
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
	 */
	protected $logo = NULL;

	/**
	 * category
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Category>
	 */
	protected $category = NULL;

	/**
	 * occupational
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Occupational>
	 */
	protected $occupational = NULL;

	/**
	 * eventDatePeriod
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Event>
	 */
	protected $eventDatePeriod = NULL;

	/**
	 * speaker
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Speaker>
	 * @cascade remove
	 */
	protected $speaker = NULL;

	/**
	 * guestSpeakers
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Speaker>
	 * @cascade remove
	 */
	protected $guestSpeakers = NULL;

	/**
	 * booking
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Booking>
	 * @cascade remove
	 */
	protected $booking = NULL;

	/**
	 * organizers
	 *
	 * @var \JS\JsCourses\Domain\Model\Organizers
	 */
	protected $organizers = NULL;

	/**
	 * availableSeatManagement
	 *
	 * @var \JS\JsCourses\Domain\Model\AvailableSeat
	 */
	protected $availableSeatManagement = NULL;

	/**
	 * Returns the title
	 *
	 * @return string $title
	 */
	public function getTitle() {
		return $this->title;
	}

	/**
	 * Sets the title
	 *
	 * @param string $title
	 * @return void
	 */
	public function setTitle($title) {
		$this->title = $title;
	}

	/**
	 * Returns the subtitle
	 *
	 * @return string $subtitle
	 */
	public function getSubtitle() {
		return $this->subtitle;
	}

	/**
	 * Sets the subtitle
	 *
	 * @param string $subtitle
	 * @return void
	 */
	public function setSubtitle($subtitle) {
		$this->subtitle = $subtitle;
	}

	/**
	 * Returns the courseId
	 *
	 * @return string $courseId
	 */
	public function getCourseId() {
		return $this->courseId;
	}

	/**
	 * Sets the courseId
	 *
	 * @param string $courseId
	 * @return void
	 */
	public function setCourseId($courseId) {
		$this->courseId = $courseId;
	}

	/**
	 * Returns the boxHeader
	 *
	 * @return string $boxHeader
	 */
	public function getBoxHeader() {
		return $this->boxHeader;
	}

	/**
	 * Sets the boxHeader
	 *
	 * @param string $boxHeader
	 * @return void
	 */
	public function setBoxHeader($boxHeader) {
		$this->boxHeader = $boxHeader;
	}

	/**
	 * Returns the lessons
	 *
	 * @return string $lessons
	 */
	public function getLessons() {
		return $this->lessons;
	}

	/**
	 * Sets the lessons
	 *
	 * @param string $lessons
	 * @return void
	 */
	public function setLessons($lessons) {
		$this->lessons = $lessons;
	}

	/**
	 * Returns the fortbildungsPoint
	 *
	 * @return string $fortbildungsPoint
	 */
	public function getFortbildungsPoint() {
		return $this->fortbildungsPoint;
	}

	/**
	 * Sets the fortbildungsPoint
	 *
	 * @param string $fortbildungsPoint
	 * @return void
	 */
	public function setFortbildungsPoint($fortbildungsPoint) {
		$this->fortbildungsPoint = $fortbildungsPoint;
	}

	/**
	 * Returns the prerequisites
	 *
	 * @return string $prerequisites
	 */
	public function getPrerequisites() {
		return $this->prerequisites;
	}

	/**
	 * Sets the prerequisites
	 *
	 * @param string $prerequisites
	 * @return void
	 */
	public function setPrerequisites($prerequisites) {
		$this->prerequisites = $prerequisites;
	}

	/**
	 * Returns the availability
	 *
	 * @return string $availability
	 */
	public function getAvailability() {
		return $this->availability;
	}

	/**
	 * Sets the availability
	 *
	 * @param string $availability
	 * @return void
	 */
	public function setAvailability($availability) {
		$this->availability = $availability;
	}

	/**
	 * Returns the fee
	 *
	 * @return string $fee
	 */
	public function getFee() {
		return $this->fee;
	}

	/**
	 * Sets the fee
	 *
	 * @param string $fee
	 * @return void
	 */
	public function setFee($fee) {
		$this->fee = $fee;
	}

	/**
	 * Returns the information
	 *
	 * @return string $information
	 */
	public function getInformation() {
		return $this->information;
	}

	/**
	 * Sets the information
	 *
	 * @param string $information
	 * @return void
	 */
	public function setInformation($information) {
		$this->information = $information;
	}

	/**
	 * Returns the file
	 *
	 * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $file
	 */
	public function getFile() {
		return $this->file;
	}

	/**
	 * Sets the file
	 *
	 * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $file
	 * @return void
	 */
	public function setFile(\TYPO3\CMS\Extbase\Domain\Model\FileReference $file) {
		$this->file = $file;
	}

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->category = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->occupational = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->eventDatePeriod = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->speaker = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->guestSpeakers = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->booking = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Adds a Event
	 *
	 * @param \JS\JsCourses\Domain\Model\Event $eventDatePeriod
	 * @return void
	 */
	public function addEventDatePeriod(\JS\JsCourses\Domain\Model\Event $eventDatePeriod) {
		$this->eventDatePeriod->attach($eventDatePeriod);
	}

	/**
	 * Removes a Event
	 *
	 * @param \JS\JsCourses\Domain\Model\Event $eventDatePeriodToRemove The Event to be removed
	 * @return void
	 */
	public function removeEventDatePeriod(\JS\JsCourses\Domain\Model\Event $eventDatePeriodToRemove) {
		$this->eventDatePeriod->detach($eventDatePeriodToRemove);
	}

	/**
	 * Returns the eventDatePeriod
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Event> $eventDatePeriod
	 */
	public function getEventDatePeriod() {
		return $this->eventDatePeriod;
	}

	/**
	 * Sets the eventDatePeriod
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Event> $eventDatePeriod
	 * @return void
	 */
	public function setEventDatePeriod(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $eventDatePeriod) {
		$this->eventDatePeriod = $eventDatePeriod;
	}

	/**
	 * Adds a Speaker
	 *
	 * @param \JS\JsCourses\Domain\Model\Speaker $speaker
	 * @return void
	 */
	public function addSpeaker(\JS\JsCourses\Domain\Model\Speaker $speaker) {
		$this->speaker->attach($speaker);
	}

	/**
	 * Removes a Speaker
	 *
	 * @param \JS\JsCourses\Domain\Model\Speaker $speakerToRemove The Speaker to be removed
	 * @return void
	 */
	public function removeSpeaker(\JS\JsCourses\Domain\Model\Speaker $speakerToRemove) {
		$this->speaker->detach($speakerToRemove);
	}

	/**
	 * Returns the speaker
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Speaker> $speaker
	 */
	public function getSpeaker() {
		return $this->speaker;
	}

	/**
	 * Sets the speaker
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Speaker> $speaker
	 * @return void
	 */
	public function setSpeaker(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $speaker) {
		$this->speaker = $speaker;
	}

	/**
	 * Adds a Speaker
	 *
	 * @param \JS\JsCourses\Domain\Model\Speaker $guestSpeaker
	 * @return void
	 */
	public function addGuestSpeaker(\JS\JsCourses\Domain\Model\Speaker $guestSpeaker) {
		$this->guestSpeakers->attach($guestSpeaker);
	}

	/**
	 * Removes a Speaker
	 *
	 * @param \JS\JsCourses\Domain\Model\Speaker $guestSpeakerToRemove The Speaker to be removed
	 * @return void
	 */
	public function removeGuestSpeaker(\JS\JsCourses\Domain\Model\Speaker $guestSpeakerToRemove) {
		$this->guestSpeakers->detach($guestSpeakerToRemove);
	}

	/**
	 * Returns the guestSpeakers
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Speaker> $guestSpeakers
	 */
	public function getGuestSpeakers() {
		return $this->guestSpeakers;
	}

	/**
	 * Sets the guestSpeakers
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Speaker> $guestSpeakers
	 * @return void
	 */
	public function setGuestSpeakers(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $guestSpeakers) {
		$this->guestSpeakers = $guestSpeakers;
	}

	/**
	 * Adds a Category
	 *
	 * @param \JS\JsCourses\Domain\Model\Category $category
	 * @return void
	 */
	public function addCategory(\JS\JsCourses\Domain\Model\Category $category) {
		$this->category->attach($category);
	}

	/**
	 * Removes a Category
	 *
	 * @param \JS\JsCourses\Domain\Model\Category $categoryToRemove The Category to be removed
	 * @return void
	 */
	public function removeCategory(\JS\JsCourses\Domain\Model\Category $categoryToRemove) {
		$this->category->detach($categoryToRemove);
	}

	/**
	 * Returns the category
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Category> $category
	 */
	public function getCategory() {
		return $this->category;
	}

	/**
	 * Sets the category
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Category> $category
	 * @return void
	 */
	public function setCategory(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $category) {
		$this->category = $category;
	}

	/**
	 * Adds a Booking
	 *
	 * @param \JS\JsCourses\Domain\Model\Booking $booking
	 * @return void
	 */
	public function addBooking(\JS\JsCourses\Domain\Model\Booking $booking) {
		$this->booking->attach($booking);
	}

	/**
	 * Removes a Booking
	 *
	 * @param \JS\JsCourses\Domain\Model\Booking $bookingToRemove The Booking to be removed
	 * @return void
	 */
	public function removeBooking(\JS\JsCourses\Domain\Model\Booking $bookingToRemove) {
		$this->booking->detach($bookingToRemove);
	}

	/**
	 * Returns the booking
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Booking> $booking
	 */
	public function getBooking() {
		return $this->booking;
	}

	/**
	 * Sets the booking
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Booking> $booking
	 * @return void
	 */
	public function setBooking(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $booking) {
		$this->booking = $booking;
	}

	/**
	 * Returns the targetGroup
	 *
	 * @return string $targetGroup
	 */
	public function getTargetGroup() {
		return $this->targetGroup;
	}

	/**
	 * Sets the targetGroup
	 *
	 * @param string $targetGroup
	 * @return void
	 */
	public function setTargetGroup($targetGroup) {
		$this->targetGroup = $targetGroup;
	}

	/**
	 * Returns the organizers
	 *
	 * @return \JS\JsCourses\Domain\Model\Organizers $organizers
	 */
	public function getOrganizers() {
		return $this->organizers;
	}

	/**
	 * Sets the organizers
	 *
	 * @param \JS\JsCourses\Domain\Model\Organizers $organizers
	 * @return void
	 */
	public function setOrganizers(\JS\JsCourses\Domain\Model\Organizers $organizers) {
		$this->organizers = $organizers;
	}

	/**
	 * Returns the totalSeat
	 *
	 * @return string $totalSeat
	 */
	public function getTotalSeat() {
		return $this->totalSeat;
	}

	/**
	 * Sets the totalSeat
	 *
	 * @param string $totalSeat
	 * @return void
	 */
	public function setTotalSeat($totalSeat) {
		$this->totalSeat = $totalSeat;
	}

	/**
	 * Returns the availableSeatManagement
	 *
	 * @return \JS\JsCourses\Domain\Model\AvailableSeat $availableSeatManagement
	 */
	public function getAvailableSeatManagement() {
		return $this->availableSeatManagement;
	}

	/**
	 * Sets the availableSeatManagement
	 *
	 * @param \JS\JsCourses\Domain\Model\AvailableSeat $availableSeatManagement
	 * @return void
	 */
	public function setAvailableSeatManagement(\JS\JsCourses\Domain\Model\AvailableSeat $availableSeatManagement) {
		$this->availableSeatManagement = $availableSeatManagement;
	}

	/**
	 * Adds a Occupational
	 *
	 * @param \JS\JsCourses\Domain\Model\Occupational $occupational
	 * @return void
	 */
	public function addOccupational(\JS\JsCourses\Domain\Model\Occupational $occupational) {
		$this->occupational->attach($occupational);
	}

	/**
	 * Removes a Occupational
	 *
	 * @param \JS\JsCourses\Domain\Model\Occupational $occupationalToRemove The Occupational to be removed
	 * @return void
	 */
	public function removeOccupational(\JS\JsCourses\Domain\Model\Occupational $occupationalToRemove) {
		$this->occupational->detach($occupationalToRemove);
	}

	/**
	 * Returns the occupational
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Occupational> $occupational
	 */
	public function getOccupational() {
		return $this->occupational;
	}

	/**
	 * Sets the occupational
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsCourses\Domain\Model\Occupational> $occupational
	 * @return void
	 */
	public function setOccupational(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $occupational) {
		$this->occupational = $occupational;
	}

	/**
	 * Returns the logo
	 *
	 * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $logo
	 */
	public function getLogo() {
		return $this->logo;
	}

	/**
	 * Sets the logo
	 *
	 * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $logo
	 * @return void
	 */
	public function setLogo(\TYPO3\CMS\Extbase\Domain\Model\FileReference $logo) {
		$this->logo = $logo;
	}

}