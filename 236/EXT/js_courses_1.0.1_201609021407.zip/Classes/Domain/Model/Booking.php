<?php
namespace JS\JsCourses\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Booking
 */
class Booking extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * salutation
	 *
	 * @var integer
	 */
	protected $salutation = '';

	/**
	 * title
	 *
	 * @var string
	 */
	protected $title = '';

	/**
	 * name
	 *
	 * @var string
	 */
	protected $name = '';

	/**
	 * lastName
	 *
	 * @var string
	 */
	protected $lastName = '';

	/**
	 * dob
	 *
	 * @var string
	 */
	protected $dob = '';

	/**
	 * occupation
	 *
	 * @var string
	 */
	protected $occupation = '';

	/**
	 * street
	 *
	 * @var string
	 */
	protected $street = '';

	/**
	 * housenumber
	 *
	 * @var string
	 */
	protected $housenumber = FALSE;

	/**
	 * zip
	 *
	 * @var string
	 */
	protected $zip = '';

	/**
	 * place
	 *
	 * @var string
	 */
	protected $place = '';

	/**
	 * country
	 *
	 * @var string
	 */
	protected $country = '';

	/**
	 * workPhone
	 *
	 * @var string
	 */
	protected $workPhone = '';

	/**
	 * privatePhone
	 *
	 * @var string
	 */
	protected $privatePhone = '';

	/**
	 * fax
	 *
	 * @var string
	 */
	protected $fax = '';

	/**
	 * email
	 *
	 * @var string
	 */
	protected $email = '';

	/**
	 * billingAddress
	 *
	 * @var string
	 */
	protected $billingAddress = FALSE;

	/**
	 * otherMessages
	 *
	 * @var string
	 */
	protected $otherMessages = '';

	/**
	 * bookedCourseInWaitingList
	 *
	 * @var boolean
	 */
	protected $bookedCourseInWaitingList = FALSE;

	/**
	 * differentBillingAddress
	 *
	 * @var boolean
	 */
	protected $differentBillingAddress = '';

	/**
	 * trainingNewsletter
	 *
	 * @var boolean
	 */
	protected $trainingNewsletter = FALSE;

	/**
	 * accommodations
	 *
	 * @var boolean
	 */
	protected $accommodations = FALSE;

	/**
	 * currentTrainingProgramByMail
	 *
	 * @var boolean
	 */
	protected $currentTrainingProgramByMail = FALSE;

	/**
	 * currentTrainingProgramByEmail
	 *
	 * @var boolean
	 */
	protected $currentTrainingProgramByEmail = FALSE;

	/**
	 * Returns the name
	 *
	 * @return string $name
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * Sets the name
	 *
	 * @param string $name
	 * @return void
	 */
	public function setName($name) {
		$this->name = $name;
	}

	/**
	 * Returns the lastName
	 *
	 * @return string $lastName
	 */
	public function getLastName() {
		return $this->lastName;
	}

	/**
	 * Sets the lastName
	 *
	 * @param string $lastName
	 * @return void
	 */
	public function setLastName($lastName) {
		$this->lastName = $lastName;
	}

	/**
	 * Returns the dob
	 *
	 * @return string $dob
	 */
	public function getDob() {
		return $this->dob;
	}

	/**
	 * Sets the dob
	 *
	 * @param string $dob
	 * @return void
	 */
	public function setDob($dob) {
		$this->dob = $dob;
	}

	/**
	 * Returns the street
	 *
	 * @return string $street
	 */
	public function getStreet() {
		return $this->street;
	}

	/**
	 * Sets the street
	 *
	 * @param string $street
	 * @return void
	 */
	public function setStreet($street) {
		$this->street = $street;
	}

	/**
	 * Returns the zip
	 *
	 * @return string $zip
	 */
	public function getZip() {
		return $this->zip;
	}

	/**
	 * Sets the zip
	 *
	 * @param string $zip
	 * @return void
	 */
	public function setZip($zip) {
		$this->zip = $zip;
	}

	/**
	 * Returns the place
	 *
	 * @return string $place
	 */
	public function getPlace() {
		return $this->place;
	}

	/**
	 * Sets the place
	 *
	 * @param string $place
	 * @return void
	 */
	public function setPlace($place) {
		$this->place = $place;
	}

	/**
	 * Returns the country
	 *
	 * @return string $country
	 */
	public function getCountry() {
		return $this->country;
	}

	/**
	 * Sets the country
	 *
	 * @param string $country
	 * @return void
	 */
	public function setCountry($country) {
		$this->country = $country;
	}

	/**
	 * Returns the occupation
	 *
	 * @return string $occupation
	 */
	public function getOccupation() {
		return $this->occupation;
	}

	/**
	 * Sets the occupation
	 *
	 * @param string $occupation
	 * @return void
	 */
	public function setOccupation($occupation) {
		$this->occupation = $occupation;
	}

	/**
	 * Returns the workPhone
	 *
	 * @return string $workPhone
	 */
	public function getWorkPhone() {
		return $this->workPhone;
	}

	/**
	 * Sets the workPhone
	 *
	 * @param string $workPhone
	 * @return void
	 */
	public function setWorkPhone($workPhone) {
		$this->workPhone = $workPhone;
	}

	/**
	 * Returns the privatePhone
	 *
	 * @return string $privatePhone
	 */
	public function getPrivatePhone() {
		return $this->privatePhone;
	}

	/**
	 * Sets the privatePhone
	 *
	 * @param string $privatePhone
	 * @return void
	 */
	public function setPrivatePhone($privatePhone) {
		$this->privatePhone = $privatePhone;
	}

	/**
	 * Returns the fax
	 *
	 * @return string $fax
	 */
	public function getFax() {
		return $this->fax;
	}

	/**
	 * Sets the fax
	 *
	 * @param string $fax
	 * @return void
	 */
	public function setFax($fax) {
		$this->fax = $fax;
	}

	/**
	 * Returns the email
	 *
	 * @return string $email
	 */
	public function getEmail() {
		return $this->email;
	}

	/**
	 * Sets the email
	 *
	 * @param string $email
	 * @return void
	 */
	public function setEmail($email) {
		$this->email = $email;
	}

	/**
	 * Returns the otherMessages
	 *
	 * @return string $otherMessages
	 */
	public function getOtherMessages() {
		return $this->otherMessages;
	}

	/**
	 * Sets the otherMessages
	 *
	 * @param string $otherMessages
	 * @return void
	 */
	public function setOtherMessages($otherMessages) {
		$this->otherMessages = $otherMessages;
	}

	/**
	 * Returns the bookedCourseInWaitingList
	 *
	 * @return boolean $bookedCourseInWaitingList
	 */
	public function getBookedCourseInWaitingList() {
		return $this->bookedCourseInWaitingList;
	}

	/**
	 * Sets the bookedCourseInWaitingList
	 *
	 * @param boolean $bookedCourseInWaitingList
	 * @return void
	 */
	public function setBookedCourseInWaitingList($bookedCourseInWaitingList) {
		$this->bookedCourseInWaitingList = $bookedCourseInWaitingList;
	}

	/**
	 * Returns the boolean state of bookedCourseInWaitingList
	 *
	 * @return boolean
	 */
	public function isBookedCourseInWaitingList() {
		return $this->bookedCourseInWaitingList;
	}

	/**
	 * Returns the trainingNewsletter
	 *
	 * @return boolean $trainingNewsletter
	 */
	public function getTrainingNewsletter() {
		return $this->trainingNewsletter;
	}

	/**
	 * Sets the trainingNewsletter
	 *
	 * @param boolean $trainingNewsletter
	 * @return void
	 */
	public function setTrainingNewsletter($trainingNewsletter) {
		$this->trainingNewsletter = $trainingNewsletter;
	}

	/**
	 * Returns the boolean state of trainingNewsletter
	 *
	 * @return boolean
	 */
	public function isTrainingNewsletter() {
		return $this->trainingNewsletter;
	}

	/**
	 * Returns the accommodations
	 *
	 * @return boolean $accommodations
	 */
	public function getAccommodations() {
		return $this->accommodations;
	}

	/**
	 * Sets the accommodations
	 *
	 * @param boolean $accommodations
	 * @return void
	 */
	public function setAccommodations($accommodations) {
		$this->accommodations = $accommodations;
	}

	/**
	 * Returns the boolean state of accommodations
	 *
	 * @return boolean
	 */
	public function isAccommodations() {
		return $this->accommodations;
	}

	/**
	 * Returns the currentTrainingProgramByMail
	 *
	 * @return boolean $currentTrainingProgramByMail
	 */
	public function getCurrentTrainingProgramByMail() {
		return $this->currentTrainingProgramByMail;
	}

	/**
	 * Sets the currentTrainingProgramByMail
	 *
	 * @param boolean $currentTrainingProgramByMail
	 * @return void
	 */
	public function setCurrentTrainingProgramByMail($currentTrainingProgramByMail) {
		$this->currentTrainingProgramByMail = $currentTrainingProgramByMail;
	}

	/**
	 * Returns the boolean state of currentTrainingProgramByMail
	 *
	 * @return boolean
	 */
	public function isCurrentTrainingProgramByMail() {
		return $this->currentTrainingProgramByMail;
	}

	/**
	 * Returns the currentTrainingProgramByEmail
	 *
	 * @return boolean $currentTrainingProgramByEmail
	 */
	public function getCurrentTrainingProgramByEmail() {
		return $this->currentTrainingProgramByEmail;
	}

	/**
	 * Sets the currentTrainingProgramByEmail
	 *
	 * @param boolean $currentTrainingProgramByEmail
	 * @return void
	 */
	public function setCurrentTrainingProgramByEmail($currentTrainingProgramByEmail) {
		$this->currentTrainingProgramByEmail = $currentTrainingProgramByEmail;
	}

	/**
	 * Returns the boolean state of currentTrainingProgramByEmail
	 *
	 * @return boolean
	 */
	public function isCurrentTrainingProgramByEmail() {
		return $this->currentTrainingProgramByEmail;
	}

	/**
	 * Returns the boolean state of housenumber
	 *
	 * @return boolean
	 */
	public function isHousenumber() {
		return $this->housenumber;
	}

	/**
	 * Returns the boolean state of billingAddress
	 *
	 * @return boolean
	 */
	public function isBillingAddress() {
		return $this->billingAddress;
	}

	/**
	 * Returns the housenumber
	 *
	 * @return string housenumber
	 */
	public function getHousenumber() {
		return $this->housenumber;
	}

	/**
	 * Sets the housenumber
	 *
	 * @param boolean $housenumber
	 * @return string housenumber
	 */
	public function setHousenumber($housenumber) {
		$this->housenumber = $housenumber;
	}

	/**
	 * Returns the salutation
	 *
	 * @return integer salutation
	 */
	public function getSalutation() {
		return $this->salutation;
	}

	/**
	 * Sets the salutation
	 *
	 * @param string $salutation
	 * @return integer salutation
	 */
	public function setSalutation($salutation) {
		$this->salutation = $salutation;
	}

	/**
	 * Returns the title
	 *
	 * @return string $title
	 */
	public function getTitle() {
		return $this->title;
	}

	/**
	 * Sets the title
	 *
	 * @param string $title
	 * @return void
	 */
	public function setTitle($title) {
		$this->title = $title;
	}

	/**
	 * Returns the billingAddress
	 *
	 * @return string billingAddress
	 */
	public function getBillingAddress() {
		return $this->billingAddress;
	}

	/**
	 * Sets the billingAddress
	 *
	 * @param boolean $billingAddress
	 * @return string billingAddress
	 */
	public function setBillingAddress($billingAddress) {
		$this->billingAddress = $billingAddress;
	}

	/**
	 * Returns the boolean state of address
	 *
	 * @return boolean
	 */
	public function isAddress() {
		return $this->address;
	}

	/**
	 * Returns the differentBillingAddress
	 *
	 * @return boolean differentBillingAddress
	 */
	public function getDifferentBillingAddress() {
		return $this->differentBillingAddress;
	}

	/**
	 * Sets the differentBillingAddress
	 *
	 * @param string $differentBillingAddress
	 * @return boolean differentBillingAddress
	 */
	public function setDifferentBillingAddress($differentBillingAddress) {
		$this->differentBillingAddress = $differentBillingAddress;
	}

}