<?php
namespace JS\JsCourses\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Courses
 */
class CoursesRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	/**
	 * insertUserData
	 *
	 * @param $insertArray
	 * @return
	 */
	public function insertUserData($insertArray) {
		if ($this->getDBHandle()->exec_insertQuery('tx_jscourses_domain_model_booking', $insertArray)) {
			return 1;
		} else {
			return 2;
		}
	}

	/**
	 * getCategoryList
	 *
	 * @param $settings
	 * @return
	 */
	public function getCategoryList($settings) {
		$field = 'uid, title, short_description, message';
		$table = 'tx_jscourses_domain_model_category';
		$groupBy = '';
		$orderBy = 'uid asc';
		$where = ' deleted = 0 AND hidden = 0 ';
		if ($settings['newsletterTemplate'] == 0) {
			if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
				$where .= ' AND pid in (' . $settings['storagePID'] . ') ';
			}
			if (isset($settings['categoryList']) && trim($settings['categoryList']) != '') {
				$where .= ' AND uid in (' . $settings['categoryList'] . ') ';
			}
		}
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
		// echo $this->getDBHandle()->SELECTquery($field, $table, $where, $groupBy, $orderBy); die;
		foreach ($res as $key => $value) {
			if ($value['title'] !== '') {
				$cat[$value['uid']] = $value;
			}
		}
		return $cat;
	}

	/**
	 * getSpeakerList
	 *
	 * @param $settings
	 * @return
	 */
	public function getSpeakerList($settings) {
		$field = 'uid, name, image, biography, qualification';
		$table = 'tx_jscourses_domain_model_speaker';
		$groupBy = '';
		$orderBy = 'uid asc';
		$where = ' deleted = 0 AND hidden = 0 ';
		if ($settings['newsletterTemplate'] == 0) {
			if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
				$where .= ' AND pid in (' . $settings['storagePID'] . ') ';
			}
		}
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
		$res1 = $this->falImages($res, 'tx_jscourses_domain_model_speaker', 'image');
		$speaker = array();
		foreach ($res1 as $key => $value) {
			if ($value['title'] !== '') {
				$speaker[$value['uid']] = $value;
				$speaker[$value['uid']]['biography'] = trim($value['biography']);
				$speaker[$value['uid']]['qualification'] = trim($value['qualification']);
			}
		}
		return $speaker;
	}

	/**
	 * getSpeakerListWithCourses
	 *
	 * @param $settings
	 * @param $uid
	 * @param $search
	 * @return
	 */
	public function getSpeakerListWithCourses($settings, $uid = 0, $search) {

		$field = 's.uid, s.name, s.image, s.biography, s.qualification, GROUP_CONCAT(DISTINCT(m.uid_local)) as courseList';
		$table = 'tx_jscourses_domain_model_speaker as s
						LEFT JOIN tx_jscourses_courses_speaker_mm AS m ON m.uid_foreign = s.uid
						LEFT JOIN tx_jscourses_domain_model_courses AS c ON c.uid = m.uid_local';
		$groupBy = '';

		$orderBy = 'uid asc';
		$where = ' s.deleted = 0 AND s.hidden = 0 AND s.name!="" ';

		$groupBy = '( s.uid )';
		if ($settings['newsletterTemplate'] == 0) {
			if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
				$where .= ' AND s.pid in (' . $settings['storagePID'] . ') ';
			}
		}

		if(intval($uid)>0){
			$where .= ' AND s.uid in (' . $uid . ') ';
		}else{
			if (isset($search['speaker']) && trim($search['speaker']) != '') {
				$where .= ' AND s.name LIKE "%' . trim($search['speaker']) . '%"';
			}
			if (isset($search['biography']) && trim($search['biography']) != '') {
				$where .= ' AND s.biography LIKE "%' . trim($search['biography']) . '%"';
			}
			if (isset($search['qualification']) && trim($search['qualification']) != '') {
				$where .= ' AND s.qualification LIKE "%' . trim($search['qualification']) . '%"';
			}
		}

		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);

		$res1 = $this->falImages($res, 'tx_jscourses_domain_model_speaker', 'image');
		$speaker = array();
		$course = $this->getCourseList($settings);
		
		foreach ($res1 as $key => $value) {
			$coursesArr = array();
			
			if (strstr($value['courseList'], ',')) {
				$cour = explode(',', $value['courseList']);
				foreach ($cour as $val) {
					if(array_key_exists($val, $course)){
						$coursesArr[$val] = $course[$val];
					}
				}
			} else {
				if(array_key_exists($value['courseList'], $course)){
					$coursesArr[$value['courseList']] = $course[$value['courseList']];
				}
			}

			$speaker[$value['uid']] = $value;
			$speaker[$value['uid']]['biography'] = trim($value['biography']);
			$speaker[$value['uid']]['qualification'] = trim($value['qualification']);
			if (is_array($coursesArr) && count($coursesArr) > 0) {
				$speaker[$value['uid']]['coursesListforSpeaker'] = $coursesArr;
			}
		}
		
		return $speaker;
	}

	/**
	 * OccupationalList
	 *
	 * @param $settings
	 * @return
	 */
	public function getOccupationalList($settings) {
		$field = 'uid, title';
		$table = 'tx_jscourses_domain_model_occupational';
		$groupBy = '';
		$orderBy = 'uid asc';
		$where = ' deleted = 0 AND hidden = 0 ';
		if ($settings['newsletterTemplate'] == 0) {
			if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
				$where .= ' AND pid in (' . $settings['storagePID'] . ') ';
			}
		}
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
		$occ = array();
		foreach ($res as $key => $value) {
			if ($value['title'] !== '') {
				$occ[$value['uid']] = $value;
			}
		}
		return $occ;
	}

	/**
	 * getOrganizersList
	 *
	 * @param $settings
	 * @return
	 */
	public function getOrganizersList($settings) {
		$field = 'uid, title, short_description';
		$table = 'tx_jscourses_domain_model_organizers';
		$groupBy = '';
		$orderBy = 'uid asc';
		$where = ' deleted = 0 AND hidden = 0 AND title!="" ';
		if ($settings['newsletterTemplate'] == 0) {
			if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
				$where .= ' AND pid in (' . $settings['storagePID'] . ') ';
			}
		}
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
		$org = array();
		foreach ($res as $key => $value) {
			if ($value['title'] !== '') {
				$org[$value['uid']] = $value;
			}
		}
		return $org;
	}

	/**
	 * getAvailableSeatList
	 *
	 * @param $settings
	 * @return
	 */
	public function getAvailableSeatList($settings) {
		$field = 'uid, title, short_description';
		$table = 'tx_jscourses_domain_model_availableseat';
		$groupBy = '';
		$orderBy = 'uid asc';
		if ($settings['newsletterTemplate'] == 0) {
			if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
				$where .= ' AND pid in (' . $settings['storagePID'] . ') ';
			}
		}
		$where = ' deleted = 0 AND hidden = 0 AND title!="" ';
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
		$avail = array();
		foreach ($res as $key => $value) {
			if ($value['title'] !== '') {
				$avail[$value['uid']] = $value;
			}
		}
		return $avail;
	}

	/**
	 * getCourseList
	 *
	 * @param $settings
	 * @return
	 */
	public function getCourseList($settings) {
		$limit = '';
		$field = 'uid, title, pid';
		$table = 'tx_jscourses_domain_model_courses';
		$groupBy = '';
		$orderBy = 'uid asc';
		$where = ' deleted = 0 AND hidden = 0 AND title!="" ';
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
		$courses = array();
		foreach ($res as $key => $value) {
			$courses[$value['uid']] = $value;
		}
		return $courses;
	}

	/**
	 * getUpcomingCoursesID
	 *
	 * @param $settings
	 * @return
	 */
	public function getUpcomingCoursesID($settings) {
		$limit = '';
		$field = 'e.uid,e.courses';
		$table = 'tx_jscourses_domain_model_event as e LEFT JOIN tx_jscourses_domain_model_courses as c ON c.uid = e.courses';
		$groupBy = '';
		$orderBy = 'e.startdate asc';
		$where = ' c.deleted = 0 AND c.hidden = 0 AND e.deleted = 0 AND e.hidden = 0 AND e.courses AND e.startdate >' . time();
		if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
			$where .= ' AND c.pid in (' . $settings['storagePID'] . ') ';
		}
		// $where = ' deleted = 0 AND hidden = 0 ';
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy);
		echo '<pre>';
		echo count($res);
		print_r($res);
		die;
	}

	/* getCoursesTitle
	 *
	 */

	/**
	 * @param $uid
	 */
	public function getCoursesTitle($uid) {
		return $getRows = $this->getDBHandle()->exec_SELECTgetRows('title', 'tx_jscourses_domain_model_courses', 'hidden = 0 and deleted = 0 and uid =' . $uid);
	}

	/* getCourses
	 *
	 * @param $settings
	 * @param $uid
	 * @param $search
	 * @param $arr
	 * @return
	 */

	/**
	 * @param $settings
	 * @param $uid
	 * @param $search
	 * @param $arr
	 */
	public function getCourses($settings, $uid, $search, $arr) {
		//$this->getUpcomingCoursesID($settings);
		$limit = '';
		if (isset($settings['limit']) && $settings['limit'] > 0) {
			$limit = $settings['limit'];
		}
		$field = 'c.* , GROUP_CONCAT(DISTINCT(ctm.uid_foreign)) as categoryList, GROUP_CONCAT(DISTINCT(s.uid_foreign) ORDER BY s.sorting asc) as speakers,
						 GROUP_CONCAT(DISTINCT(gs.uid_foreign)) as guest_speakers, GROUP_CONCAT(DISTINCT(o.uid_foreign)) as occupationalList ,
						 org.title as organizersTitle, org.short_description as organizersShortDescription,
						 avail.title as availableTitle, avail.short_description as availableShortDescription
						 ';
		$tableOLD = 'tx_jscourses_domain_model_courses as c
						LEFT JOIN tx_jscourses_courses_category_mm AS ctm ON ctm.uid_local = c.uid  
						LEFT JOIN tx_jscourses_courses_speaker_mm AS s ON s.uid_local = c.uid  
						LEFT JOIN tx_jscourses_courses_guestspeakers_speaker_mm AS gs ON gs.uid_local = c.uid  
						LEFT JOIN tx_jscourses_courses_occupational_mm AS o ON o.uid_local = c.uid 
						LEFT JOIN tx_jscourses_domain_model_organizers AS org ON org.uid = c.organizers 
						LEFT JOIN tx_jscourses_domain_model_availableseat AS avail ON avail.uid = c.available_seat_management 
						';
		$table = 'tx_jscourses_domain_model_courses as c
						LEFT JOIN tx_jscourses_domain_model_event as e ON e.courses = c.uid 
						LEFT JOIN tx_jscourses_courses_category_mm AS ctm ON ctm.uid_local = c.uid  
						LEFT JOIN tx_jscourses_courses_speaker_mm AS s ON s.uid_local = c.uid  
						LEFT JOIN tx_jscourses_courses_guestspeakers_speaker_mm AS gs ON gs.uid_local = c.uid  
						LEFT JOIN tx_jscourses_courses_occupational_mm AS o ON o.uid_local = c.uid 
						LEFT JOIN tx_jscourses_domain_model_organizers AS org ON org.uid = c.organizers 
						LEFT JOIN tx_jscourses_domain_model_availableseat AS avail ON avail.uid = c.available_seat_management 
						';
		$orderBy = 'e.startdate asc';
		$groupBy = 'c.uid';
		if ($settings['newsletterTemplate'] == 0) {
			if (isset($arr['n']) && $arr['n'] == 1) {
				
			} else {
				if (isset($settings['storagePID']) && $settings['storagePID'] != '') {
					$where .= ' AND c.pid in (' . $settings['storagePID'] . ') ';
				}
			}
		} else {
			if (isset($settings['coursesList'])) {
				$where .= ' AND c.uid in (' . $settings['coursesList'] . ')';
				$orderBy = ' field(c.uid,' . $settings['coursesList'] . ')';
			} else {
				return;
			}
		}
		$uid = intval($uid);
		if ($uid > 0) {
			$where .= ' AND c.uid = ' . $uid;
		} else {
			if (isset($search['title']) && trim($search['title']) != '') {
				//$where .= ' AND c.title LIKE "%' . trim($search['title']) . '%"';
				$searchArr  = \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode(' ', $search['title'], true);
				
				$whr = array();

				foreach ($searchArr as $key => $value) {
					$whr[] = ' c.title LIKE "%' . $value . '%" ';
				}
				
				$where .= ' AND ( '.implode($whr, " OR ").' ) ';
				
			}
			if (isset($search['id']) && trim($search['id']) != '') {
				$where .= ' AND c.course_id LIKE "%' . trim($search['id']) . '%"';
			}
			$where .= ' AND e.hidden = 0 AND e.courses AND e.startdate > ' . time();
		}
		$where = ' c.deleted = 0 AND c.hidden = 0 ' . $where;
		$res = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy, $orderBy, $limit);
		//echo $this->getDBHandle()->SELECTquery($field,$table,$where,$groupBy,$orderBy); die;
		$res1 = $this->falImages($res, 'tx_jscourses_domain_model_courses');
		$catArr = $this->getCategoryList($settings);
		$speArr = $this->getSpeakerList($settings);
		$occArr = $this->getOccupationalList($settings);
		$data = array();
		foreach ($res1 as $key => $value) {

			$catArr1 = array();
			if ($value['categoryList'] != '') {
				if (strstr($value['categoryList'], ',')) {
					$cat = explode(',', $value['categoryList']);
					foreach ($cat as $val) {
						if (array_key_exists($val, $catArr)) {
							$catArr1[$val] = $catArr[$val];
						}
					}
				} else {
					if (array_key_exists($value['categoryList'], $catArr)) {
						$catArr1[$value['categoryList']] = $catArr[$value['categoryList']];
					}
				}
			}
			if (isset($search['category']) && $search['category'] > 0) {
				if (!array_key_exists($search['category'], $catArr1)) {
					continue;
				}
			}
			if (isset($arr['n']) && $arr['n'] == 1) {
				
			} else {
				if (isset($settings['categoryList']) && trim($settings['categoryList']) != '') {
					if (strstr($value['categoryList'], ',')) {
						$cat = explode(',', $value['categoryList']);
						foreach ($cat as $val) {
							if (!array_key_exists($val, $catArr1)) {
								continue;
							}
						}
					} else {
						if (!array_key_exists($value['categoryList'], $catArr1)) {
							continue;
						}
					}
					if (count($catArr1) == 0) {
						continue;
					}
				}
			}
			$occArr1 = array();
			if ($value['occupationalList'] != '') {
				if (strstr($value['occupationalList'], ',')) {
					$cat = explode(',', $value['occupationalList']);
					foreach ($cat as $val) {
						$occArr1[$val] = $occArr[$val];
					}
				} else {
					$occArr1[$value['occupationalList']] = $occArr[$value['occupationalList']];
				}
			}
			if (isset($search['occupational']) && $search['occupational'] > 0) {
				if (!array_key_exists($search['occupational'], $occArr1)) {
					continue;
				}
			}
			$speArr1 = array();
			if ($value['speakers'] != '') {
				if (strstr($value['speakers'], ',')) {
					$cat = explode(',', $value['speakers']);
					foreach ($cat as $val) {
						$speArr1[$val] = $speArr[$val];
					}
				} else {
					$speArr1[$value['speakers']] = $speArr[$value['speakers']];
				}
			}
			if (isset($search['speaker']) && $search['speaker'] > 0) {
				if (!array_key_exists($search['speaker'], $speArr1)) {
					continue;
				}
			}
			$data[$value['uid']] = $value;
			$data[$value['uid']]['categories'] = $catArr1;
			$data[$value['uid']]['speakersList'] = $speArr1;

			$field = 'uid, title, startdate , enddate';
			$table = 'tx_jscourses_domain_model_event';
			$where = ' deleted = 0 AND hidden = 0 AND courses = ' . $value['uid'];
			$data[$value['uid']]['eventTime'] = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where);

			$speArr2 = array();

			if (trim($value['guest_speakers']) != '') {
				if (strstr($value['guest_speakers'], ',')) {
					$cat = explode(',', $value['guest_speakers']);
					foreach ($cat as $val) {
						$speArr2[$val] = $speArr[$val];
					}
				} else {
					$speArr2[$value['guest_speakers']] = $speArr[$value['guest_speakers']];
				}
			}

			$data[$value['uid']]['guestSpeakersList'] = $speArr2;
		}

		if ($uid > 0) {
			return $data[$uid];
		}
		return $data;
	}

	/**
	 * getDBHandle
	 *
	 * @return
	 */
	public function getDBHandle() {
		return $GLOBALS['TYPO3_DB'];
	}

	/**
	 * falImages
	 *
	 * @param $result
	 * @param $tablename
	 * @param $fieldname
	 * @return
	 */
	public function falImages($result, $tablename = NULL, $fieldname = NULL) {
		$query = $this->createQuery();
		$query->getQuerySettings()->setReturnRawQueryResult(TRUE);
		$where = '';
		if ($tablename != '') {
			$where = ' AND tablenames = "' . $tablename . '"';
		}
		if ($fieldname != '') {
			$where .= ' AND fieldname IN ("' . $fieldname . '")';
		}
		foreach ($result as $key => $value) {
			$whr = ' deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];
			$sysImages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr);
			$arr = '';
			foreach ($sysImages as $key1 => $value1) {
				$sysImageDetail = 'SELECT * FROM sys_file WHERE uid = ' . $value1['uid_local'];
				$query->statement($sysImageDetail);
				$sysImageDetail = $query->execute();
				$arr[$value1['fieldname']][$value1['uid']]['identifier'] = 'fileadmin' . $sysImageDetail[0]['identifier'];
				$arr[$value1['fieldname']][$value1['uid']]['title'] = $value1['title'];
				$arr[$value1['fieldname']][$value1['uid']]['caption'] = $value1['description'];
				$arr[$value1['fieldname']][$value1['uid']]['extension'] = $sysImageDetail[0]['extension'];
				$arr[$value1['fieldname']][$value1['uid']]['mime_type'] = $sysImageDetail[0]['mime_type'];
				$arr[$value1['fieldname']][$value1['uid']]['name'] = $sysImageDetail[0]['name'];
				$arr[$value1['fieldname']][$value1['uid']]['uid'] = $sysImageDetail[0]['uid'];
				$arr1 = \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode('/', $sysImageDetail[0]['mime_type'], true);
				$arr[$value1['fieldname']][$value1['uid']]['mime'] = $arr1[0];
				$arr[$value1['fieldname']][$value1['uid']]['type'] = $arr1[1];
				$arr[$value1['fieldname']][$value1['uid']]['imageName'] = basename($sysImageDetail[0]['identifier']);
			}
			$result[$key]['media'] = $arr;
		}
		return $result;
	}

}