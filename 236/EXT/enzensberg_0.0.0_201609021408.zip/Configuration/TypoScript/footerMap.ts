

lib.footerMap = CONTENT
lib.footerMap.table =  tt_content
lib.footerMap.select.pidInList = {$config.footerMap.Pid}
lib.footerMap.select.uidInList = {$config.footerMap.Uid}