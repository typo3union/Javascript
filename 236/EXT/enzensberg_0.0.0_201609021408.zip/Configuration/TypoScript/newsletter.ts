
lib.newsLetterLogo = COA
lib.newsLetterLogo {
  10 = IMG_RESOURCE
  10 {
    file {
      import =  uploads/media/
      import.data = levelmedia:-1, slide
      import.listNum = 0
      treatIdAsReference = 1
      width = 150
      height = 46
    }
      
    titleText.data = page:subtitle
    altText.data = page:subtitle
    stdWrap.typolink.parameter.data = 
  }
}

lib.newsLetterLogo.wrap = <a href='http://{$config.baseURL}'><img src="http://{$config.baseURL}/|" style="display:block;" /></a>



lib.newsLetterTitle = TEXT
lib.newsLetterTitle.value = {$newsletter.title}

lib.newsLetterTitleBorder = TEXT
lib.newsLetterTitleBorder.value = http://{$config.baseURL}/{$newsletter.titleBorder}

lib.newsLetterFooterTitle = TEXT
lib.newsLetterFooterTitle.value = {$newsletter.footerTitle}

lib.newsLetterBaseURl = TEXT
lib.newsLetterBaseURl.value = {$config.baseURL}

lib.newsletterUnsubscribe =TEXT
lib.newsletterUnsubscribe.value = <a style="color: #ffffff; font-size: 14px; font-weight: 400; text-decoration: none;"  href="index.php?id={$newsletter.unsubscribe.link}&cmd=infomail&backURL={$newsletter.unsubscribe.link}&uid=###USER_uid###">{$newsletter.unsubscribe.text}</a>


lib.newsletterFooterMenu= COA
lib.newsletterFooterMenu{

	10= HMENU
	10.special = list  
	10.special.value = {$newsletter.footerMenu.Pid}
	10.1 = TMENU
	10.1 {
		wrap = <p style="text-align:right;">|</p>
		noBlur = 1
		expAll = 1
		IFSUB = 1  
	   
		NO {
			#wrapItemAndSub = <li style="float: left; margin:0px;">|</li>|*|<li style="float: left; margin:0px;">|</li>|*|<li style="float: left; margin:0px;">|</li>
			stdWrap.wrap = |*||&nbsp;&#124;&nbsp;|*| |
			ATagTitle.field = 1
			ATagParams = style="color: #ffffff; font-size: 14px; font-weight: 400; text-decoration: none;"
		}
	}
}

tt_content.stdWrap.innerWrap.cObject = CASE
tt_content.stdWrap.innerWrap.cObject {
      key.field = section_frame
      111 = TEXT
      111.value = <table width="570" border="0" align="center" cellspacing="0" cellpadding="0" valign="top"><tbody><tr><td valign="top" height="20" bgcolor="#e5e5e5" style="height: 20px;"></td></tr></tbody></table>
} 

tt_content.stdWrap.innerWrap.cObject = CASE
tt_content.stdWrap.innerWrap.cObject {
      key.field = section_frame
      112 = TEXT
      112.value = <table width="570" border="0" bgcolor="#fff" cellspacing="0" cellpadding="0" valign="top"><tbody><tr><td style="padding: 0 20px; font-family: 'Hind',sans-serif; font-weight: 400; line-height: 23px; background-color: #ffffff;">|</td></tr></tbody></table>
} 

tt_content.stdWrap.innerWrap.cObject = CASE
tt_content.stdWrap.innerWrap.cObject {
      key.field = section_frame
      113 = TEXT
      113.value = <table width="570" border="0" bgcolor="#fff" align="center" cellspacing="0" cellpadding="0" valign="top"><tbody><tr><td style="padding: 0 20px; font-family: 'Hind',sans-serif; font-weight: 400; line-height: 23px; text-align: center; background-color: #ffffff;">|</td></tr><tr><td valign="top" style="height:20px;background-color:#fff;"></td></tr></tbody></table>
} 

tt_content.stdWrap.innerWrap.cObject = CASE
tt_content.stdWrap.innerWrap.cObject {
      key.field = section_frame
      114 = TEXT
      114.value = <table width="570" border="0" bgcolor="#fff" cellspacing="0" cellpadding="0" valign="top"><tbody><tr> <td style="border-top:3px solid #91a2c7;" valign="top"></td> </tr><tr><td style="padding: 0 20px; font-family: 'Hind',sans-serif; font-weight: 400; line-height: 23px; background-color: #ffffff;">|</td></tr></tbody></table>
} 