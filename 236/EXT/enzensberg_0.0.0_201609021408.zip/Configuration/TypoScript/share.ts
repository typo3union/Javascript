lib.share.social = TEXT
lib.share.social.value = <ul><li><a href="#"><img src="typo3conf/ext/enzensberg/Resources/Public/images/s-icon.png" alt="img" /></a></li><li><a href="{$share.url.facebook}"><img src="typo3conf/ext/enzensberg/Resources/Public/images/fb-icon.png" alt="img" /></a></li><li><a href="{$share.url.youtube}"><img src="typo3conf/ext/enzensberg/Resources/Public/images/youtb-icon.png" alt="img" /></a></li><li><a href="{$share.url.clinik_review}"><img src="typo3conf/ext/enzensberg/Resources/Public/images/md-icon.png" alt="img" /></a></li></ul>


#lib.share.mapLink = TEXT
#lib.share.mapLink.value = <a href="#javascript;" class="toBottom"><img src="typo3conf/ext/enzensberg/Resources/Public/images/map-sm-icon.png" alt="map"/></a>

lib.share.mapLink  = TEXT
lib.share.mapLink {
 value = <img alt="map" src="typo3conf/ext/enzensberg/Resources/Public/images/map-sm-icon.png">
 typolink.parameter = {$config.klinikfinder.UID}
 typolink.title = Klinikfinder
}


lib.share.mobMmapLink  = TEXT
lib.share.mobMmapLink {
 value = <img alt="map-mobile" src="typo3conf/ext/enzensberg/Resources/Public/images/map-sub.png">
 typolink.parameter = {$config.klinikfinder.UID}
 typolink.title = Klinikfinder
}

#lib.share.mobMmapLink = TEXT
#lib.share.mobMmapLink.value = <a href="#javascript;" class="toBottom t3"><img src="typo3conf/ext/enzensberg/Resources/Public/images/map-sub.png" alt="map"/></a>