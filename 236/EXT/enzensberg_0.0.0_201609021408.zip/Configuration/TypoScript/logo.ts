lib.logo = COA
lib.logo {
	10 = IMAGE
	10 {
		file {
			import =  uploads/media/
			import.data = levelmedia:-1, slide
			import.listNum = 0
			treatIdAsReference = 1
			width = 150
			height = 46
		}
      
		titleText.data = page:subtitle
		altText.data = page:subtitle
		stdWrap.typolink.parameter.data = leveluid:0
	}
}


[globalVar = TSFE:page|tx_fed_page_controller_action = enzensberg->Home3]

lib.logo = COA
lib.logo {
  10 = IMAGE
  10 {
    file {
      import =  uploads/media/
      import.data = levelmedia:-1, slide
      import.listNum = 1
      treatIdAsReference = 1
      width = 150
      height = 46
    }

    titleText.data = page:subtitle
    altText.data = page:subtitle
    stdWrap.typolink.parameter.data = leveluid:0
  }
}

[END]