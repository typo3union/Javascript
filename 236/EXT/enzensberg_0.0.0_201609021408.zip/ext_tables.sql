CREATE TABLE pages (
        pageicon text,
        videobanner int(11) DEFAULT '0' NOT NULL,
        isprofessional int(11) DEFAULT '0' NOT NULL,
); 
