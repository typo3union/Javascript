﻿================================================
To translate: Users manual
================================================

This is a place where the translation of the User Manual could be possibly added. This could be handy when a company is compiling a documentation towards the End User in a native language. It has the possibility to include this file in the build process.

To translate: documentation of how to use the extension, how it works, how to apply it if it's a website plugin.

.. figure:: Images/UserManualDe/BackendView.png
		:width: 500px
		:alt: Backend view

		To translate: Default Backend view (caption of the image)

		To translate: The Backend view of TYPO3 after the user has clicked on module "Page". (legend of the image)
