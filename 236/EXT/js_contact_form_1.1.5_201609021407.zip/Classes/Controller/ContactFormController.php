<?php
namespace JS\JsContactForm\Controller;

session_start();
ini_set("display_errors",1);


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015 Jainish Senjaliya <jainish.online@gmail.com>
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!

 ***************************************************************/

/**
 *
 * ContactFormController
 *
 * @package js_contact_form
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 */

class ContactFormController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * contactFormRepository
	 * 
	 * @var \JS\JsContactForm\Domain\Repository\ContactFormRepository
	 * @inject
	 */

	protected $contactFormRepository = NULL;

	/**
	 * contactFormService
	 *
	 * @var \JS\JsContactForm\Service\ContactFormService
	 * @inject
	 */

	protected $contactFormService;
	
	/**
	 * captchaService
	 *
	 * @var \JS\JsContactForm\Service\CaptchaService
	 * @inject
	 */
	protected $captchaService;

    /**
     * Path to captcha image
     *
     * @var \string
     */
    protected $sesssionName = 'JsContactForm_captcha_value';


	/**
	 * action contactForm
	 *
	 * @return void
	 */

	public function contactFormAction() {

		
		$this->fullURL = \TYPO3\CMS\Core\Utility\GeneralUtility::getIndpEnv('TYPO3_SITE_URL');
		$this->cObject = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('tslib_cObj');

		$suc = 0;

		if(isset($_SESSION['contactMessage'])){
			$suc = $_SESSION['contactMessage'];
			unset($_SESSION['contactMessage']);
		}

		$requiredFieldsArr	= $this->settings['requiredFields'];
		$fieldsArr 			= $this->settings['formFields'];

		$arr = $requireArr 	= $require = array();

		$Formfield = $this->contactFormService->missingConfiguration($this->settings);
		if($Formfield==1){
			if(trim($fieldsArr)!=""){
				if(strstr($fieldsArr, ",")){
					$arr = explode(",",$fieldsArr);		
				}
				$Formfield = 1;
			}else{
				$Formfield = 0;
			}
		}

		if(trim($requiredFieldsArr)!=""){
			if(strstr($requiredFieldsArr, ",")){
				$require = explode(",",$requiredFieldsArr);
				foreach ($require as $key => $value) {
					if($value!=""){
						$requireArr[] = trim($value);
					}
				}		
			}else{
				$requireArr[] = $requiredFieldsArr;
			}
		}

		$fields =array();

		if($this->request->hasArgument('contactSubmit')){
			$fieldsValue = $this->request->getArguments();					
		}

		foreach ($arr as $key => $value) {
			$val = trim($value);

			if($val!=""){
				$validate = in_array($val, $requireArr)?"validate":"";
				$fields[$val] = array("field"=>$val,"validate"=>$validate,"value"=>$fieldsValue[$val]);
			}
		}


		if($this->request->hasArgument('contactSubmit')){

			$formFields = $this->request->getArguments();

			$error = $this->contactFormService->validate($formFields,$requireArr);

			foreach ($error as $key => $value) {
				$fields[$value]["error"] = "error";
			}

			$err = '';

			if(count($error)>0){

				$err = $error;

			}else{

				$_SESSION['contactMessage'] = $this->contactFormService->insertUserData($formFields,$this->settings['storagePID'],$this->settings['subjectUser']);
				$suc = 1;
			}

			// Mail sent to user and admin

			if($suc==1){

				//$confi['additionalParams'] = "&L=".(int)\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('L');
				$confi['returnLast'] = 'url'; // get it as URL
				$confi['parameter'] =  $GLOBALS['TSFE']->id;
				$currentPage = $this->fullURL.htmlspecialchars($this->cObject->typolink(NULL, $confi)); 

				$arr = array('firstname'	=> $formFields['firstname'],
					         'lastname' 	=> $formFields['lastname'],
					         'company' 		=> $formFields['company'],
					         'url' 			=> $formFields['url'],
					         'email' 		=> $formFields['email'],
					         'phone' 		=> $formFields['phone'],
					         'fax'	 		=> $formFields['fax'],
					         'address' 		=> $formFields['address'],
					         'zip' 			=> $formFields['zip'],
					         'city' 		=> $formFields['city'],
					         'country' 		=> $formFields['country'],
					         'message' 		=> $formFields['message']
					        );

				$mainLogo = "typo3conf/ext/js_contact_form/Resources/Public/Images/logo.png";

				$logo1 = $this->settings['logoInMail'];

				if(strstr($logo1,"www") || strstr($logo1,"http")){
					$logoPath = $logo1;
				}else{
					$logoPath = $this->fullURL.$logo1;
				}

				if($this->contactFormService->checkRemoteFile($logoPath)){
					$logo = $logoPath;
				}else{
					$logo = $this->fullURL.$mainLogo;
				}

				$arr1 = array(
					         'baseURL' 		=> $this->fullURL,
					         'userName' 	=> $formFields['firstname']." ".$formFields['lastname'] ,
					         'siteLogo' 	=> $logo,
					         'logoLink'		=> $logoLink = $this->settings['logoLink']==""?$this->fullURL:$this->settings['logoLink']
					        );


				foreach ($arr as $key => $value) {
					if($value!=""){
						$mailFields['mail'][] = array('field'=>$key,'value'=>$value); 
					}
				}

				$returnPath 	= $attachements = $plain =  $bccName = $bccEmail = "";

				$fromName		=  $this->settings['senderName'];
				$fromEmail		=  $this->settings['senderEmail'];

				//$replyToEmail	=  $this->settings['noreply'];
				//$replyToName	=  $this->settings['noreplyEmail'];
				$replyToEmail	=  $this->settings['noreplyEmail'];
				$replyToName	=  $this->settings['noreply'];
				$sendMailUser	=  $this->settings['sendMailUser'];	
				$emailSignature = array('mailsignature' => $this->settings['mailsignature']);


				$userContent = $this->objectManager->get('TYPO3\\CMS\\Fluid\\View\\StandaloneView');

				$templateName = 'Email/mailContent.html';

				$extbaseFrameworkConfiguration = $this->configurationManager->getConfiguration(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FRAMEWORK);

				$templateRootPath = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($extbaseFrameworkConfiguration['view']['templateRootPath']);

				$templatePathAndFilename = $templateRootPath.$templateName;

				$userContent->setTemplatePathAndFilename($templatePathAndFilename);

				$userContent->assignMultiple($mailFields);

				$userContent->assignMultiple($arr1);
				$userContent->assignMultiple($arr);
				$userContent->assignMultiple($emailSignature);
				
				$userContents = $userContent->render();

				if($sendMailUser==1){

					$userEmailBody = nl2br(nl2br(html_entity_decode($this->settings['mailcontent']['user'], ENT_QUOTES)));

					$userEmailBody = str_replace("{username}", $formFields['firstname'], $userEmailBody);

					$userEmailBody = str_replace("{currentPage}", $currentPage, $userEmailBody);

					$userEmailBody = str_replace("{userContent}", $userContents, $userEmailBody);

					$to = $formFields['email'];

					$subject		=  $this->settings['subjectUser'];
					
					if($to!=""){
						$toArr = array(0=>array("name"=>$formFields['firstname'],"email"=>$to));
						$res = $this->contactFormService->sendMail($toArr, $subject, $userEmailBody, $plain, $fromEmail, $fromName, $replyToEmail, $replyToName, $bccName, $bccEmail, $returnPath, $attachements);
					}
				}

				$sendMailAdmin	=  $this->settings['sendMailAdmin'];

				if($sendMailAdmin==1){

					$adminEmailBody = nl2br(nl2br(html_entity_decode($this->settings['mailcontent']['admin'], ENT_QUOTES)));

					$adminEmailBody = str_replace("{currentPage}", $currentPage, $adminEmailBody);

					$adminEmailBody = str_replace("{userContent}", $userContents, $adminEmailBody);

					$adminEmailBody = str_replace("{username}", $formFields['firstname'], $adminEmailBody);

					$to			=  $this->settings['adminEmail'];
					
					$subject	=  $this->settings['subjectAdmin'];

					$fromName	=  $formFields['firstname'];
					$fromEmail	=  $formFields['email'];
					
					$fromName		=  $this->settings['noreply'];
					$fromEmail		=  $this->settings['noreplyEmail'];

					if($to!=""){

						$toArr = array(0=>array("name"=>$this->settings['adminName'],"email"=>$to));
						
						$res = $this->contactFormService->sendMail($toArr, $subject, $adminEmailBody, $plain, $fromEmail, $fromName, $replyToEmail, $replyToName, $bccName, $bccEmail, $returnPath, $attachements);

					}
				}

				if(isset($this->settings['redirectPID']) && $this->settings['redirectPID']>0){
					$rid = $this->settings['redirectPID'];
				}else{
					$rid = $GLOBALS['TSFE']->id;
				}

				$this->redirectURL($this->cObject,$rid,$this->fullURL);	
			}
		}


		$this->contentObj = $this->configurationManager->getContentObject();

		$uid = $this->contentObj->data['uid'];

		$sucArr = array('message'=> $suc,
						'successMessage'=> $this->settings['messageAfterSubmit']
						);

		$captchaImages = $this->captchaService->generateCaptcha($this->settings,$this->sesssionName);

		
		$this->view->assign('captchaImages', $captchaImages);
		$this->view->assign('message', $suc);
		$this->view->assign('success', $sucArr);
		$this->view->assign('userData', $formFields);
		$this->view->assign('errors', $err);
		$this->view->assign('formFields', $fields);
		$this->view->assign('template', $Formfield);

		// Include Additional Data

		$this->contactFormService->includeAdditionalData($this->settings);

	}

	/**
	 * redirectURL
	 *
	 * @param $cObject
	 * @param $pid
	 * @param $fullURL
	 * @param $additionalParams
	 * @return
	 */

	public function redirectURL($cObject, $pid, $fullURL, $additionalParams = "") {

			$configurations['additionalParams'] = $additionalParams;
			$configurations['returnLast'] = 'url'; // get it as URL
			$configurations['parameter'] = $pid;
			$url  = $fullURL.$cObject->typolink(NULL, $configurations);
			header("Location:".$url);
			die;
	}

}